/**
 * Created by vaibhav_parkhi on 12/1/2015.
 */
///client class
function Client(){

}
// Default client static property
Client.prototype.name="Pepsico";
Client.prototype.geo="Europe";
Client.prototype.deploymentEnv=AUSTIN_DEV_ENV;
Client.prototype.defaultCountry="";
Client.prototype.trendedWS = 1;
Client.prototype.clientStyleClass="client";
Client.prototype.defaultProcessIndex=0;
Client.prototype.hierarchyPath="H0:Global";
Client.prototype.aggregationType="COUNT";
Client.prototype.drillDownHierarchyLabel="Global";
Client.prototype.commentAPITokenKey="Td9jvC77jEWcpLMdkscXlGbSNCSjQlFU";
Client.prototype.apiversion="1.0";
Client.prototype.isLiferay=false;
Client.prototype.isLoginServlet=false;




/**
 * Created by _desktop_admin_pune on 10-Apr-17.
 */
