/**
 * Created by vaibhav_parkhi on 7/12/2016.
 */
location_macro.factory("dashboardDataProcessFactory",function(utilityService,$location,$q, $rootScope){
    var dashboardDataProcessFactory={};


    /*
     process configuration

     */
    dashboardDataProcessFactory.processConfigData = function ($scope, configArr) {
        var deferred = $q.defer();
        for (var i = 0; i < configArr.config1.length; i++) {

            if (configArr.config1[i].H0_LABEL != undefined) {
                $scope.currentClientCofig.drillDownHierarchyLabel = configArr.config1[i].H0_LABEL;
            }
            if (configArr.config1[i].DESKTOPAPIVERSION != undefined) {
                $scope.wsTempParamObj.apiversion = configArr.config1[i].DESKTOPAPIVERSION;

            }
            if (configArr.config1[i].CLIENT_NAME != undefined) {
                $scope.currentClientCofig.clientStyleClass = configArr.config1[i].CLIENT_NAME.toLowerCase();
            }
            if (configArr.config1[i].PREDICTIVEON != undefined) {
                $scope.isPredictiveOn = configArr.config1[i].PREDICTIVEON;
            }


            if (configArr.config1[i].WEIGHTEDAVERAGEON != undefined) {
                $scope.isWeightedAverageOn = configArr.config1[i].WEIGHTEDAVERAGEON;
            }
            console.log($scope.isWeightedAverageOn)

            if (configArr.config1[i].AVAILABLEGRAPH != undefined) {
                //$scope.wsTempParamObj.avaliableGraphs = configArr.config1[i].AVAILABLEGRAPH.split(",");
                var tempArr = configArr.config1[i].AVAILABLEGRAPH.split(",");
                for (var j = 0; j < $scope.wsTempParamObj.avaliableGraphs.length; j++) {
                    for (var k = 0; k < tempArr.length; k++) {
                        if (j == parseInt(tempArr[k] - 1)) {
                            $scope.wsTempParamObj.avaliableGraphs[j] = true;
                        }
                    }

                }
            }

            if (configArr.config1[i].DEFAULTINGGRAPH != undefined) {
                $scope.wsTempParamObj.defaultGraph = configArr.config1[i].DEFAULTINGGRAPH;
            }

            if (configArr.config1[i].DRILLDOWNMAXDEPTH != undefined) {
                $scope.maxDrillDownDepth = configArr.config1[i].DRILLDOWNMAXDEPTH;
                console.log($scope.maxDrillDownDepth);
            }
        }
        for (var i = 0; i < configArr.config1.length; i++) {
            try {
                for (var j = 0; j <= $scope.maxDrillDownDepth; j++) {
                    if (configArr.config1[i]['H' + j + "_LABEL"] != undefined) {
                        $scope.drillDownLabelArr[j] = configArr.config1[i]['H' + j + "_LABEL"];
                    }
                }
            } catch (err) {
                console.log(err);
            }
        }

        console.log($scope.drillDownLabelArr);

        if ($scope.wsTempParamObj.apiversion == "2.0" || $scope.wsTempParamObj.apiversion == "2.1" || $scope.wsTempParamObj.apiversion == "2.2" || $scope.wsTempParamObj.apiversion == "3.0") {
            $scope.metricTypeArr = configArr.metricType;
            $scope.wsTempParamObj.dataType = $scope.metricTypeArr[0].metricType;
        }
        if ($scope.wsTempParamObj.apiversion == "2.1" || $scope.wsTempParamObj.apiversion == "2.0" || $scope.wsTempParamObj.apiversion == "1.0" || $scope.wsTempParamObj.apiversion == "2.2" || $scope.wsTempParamObj.apiversion == "3.0") {
            ///$scope.rolesArr=[];
            //$scope.viewerRole=false;
            //$scope.approverRole=false;
            if (configArr.roleData != undefined && configArr.roleData.length > 0) {
                for (var i = 0; i < configArr.roleData.length; i++) {
                    if (configArr.roleData[i].roleID == 0) {
                        $scope.viewerRole = true;
                    } else if (configArr.roleData[i].roleID == 1) {
                        $scope.approverRole = true;
                    }
                }

                if (!$scope.approverRole && $scope.viewerRole) {
                    if ($location.path() == "/top_metrics_page_one" || $location.path() == "/top_metrics_page_two") {
                        $rootScope.$on('$locationChangeSuccess', function (next, current) {
                            deferred.resolve();
                        });
                    } else {
                        /*$location.path("/digital_dashboard");*/
                    }

                } else {
                    deferred.resolve();
                }


            } else {
                if (!$scope.approverRole) {
                    if ($location.path() == "/top_metrics_page_one" || $location.path() == "/top_metrics_page_two") {

                        $rootScope.$on('$locationChangeSuccess', function (next, current) {
                            deferred.resolve();
                        });
                    } else {
                        /*$location.path("/digital_dashboard");*/
                    }

                } else {
                    deferred.resolve();
                }
            }


        }
        if ($location.path() == "/digital_dashboard" || $location.path() == "/digital-dashboard" || $location.path() == "/approver") {
            if ($location.path() == "/approver") {
                $scope.wsTempParamObj.defaultGraph = 1;
            }
            $scope.initAggregationData();
            $scope.getAggregationsData($scope.wsTempParamObj);
        } else {
            $scope.initAggregationData();
            $scope.getAggregationsData($scope.wsTempParamObj);
            $scope.getFullHierarchy($scope.wsTempParamObj);
        }
    }


    /* process the Aggregations WS API*/
    dashboardDataProcessFactory.processAggregationsData = function ($scope, aggregationsData) {
        console.log($scope.aggregationsGraphData);
        $scope.aggregationsBarGraphData = aggregationsData.graph;
        if($scope.aggregationsBarGraphData.length>0){
            $scope.totalOfDoughnutChart=$scope.aggregationsBarGraphData[0].R+$scope.aggregationsBarGraphData[0].G+$scope.aggregationsBarGraphData[0].Y;

            //Show last month's data value on first page
            $scope.doughnutChartData.datasets[0].data[0]=$scope.selectedAggregationRecord.red=$scope.aggregationsBarGraphData[0].R;
            $scope.doughnutChartData.datasets[0].data[1]=$scope.selectedAggregationRecord.green=$scope.aggregationsBarGraphData[0].G;
            $scope.doughnutChartData.datasets[0].data[2]=$scope.selectedAggregationRecord.yellow=$scope.aggregationsBarGraphData[0].Y;
            $scope.doughnutChartBottomDataY.datasets[0].data[0]=$scope.selectedAggregationRecord.yellow;
            $scope.doughnutChartBottomDataY.datasets[0].data[1]=($scope.selectedAggregationRecord.green+$scope.selectedAggregationRecord.red);
            $scope.doughnutChartBottomDataR.datasets[0].data[0]=$scope.selectedAggregationRecord.red;
            $scope.doughnutChartBottomDataR.datasets[0].data[1]=($scope.selectedAggregationRecord.yellow+$scope.selectedAggregationRecord.green);
            $scope.doughnutChartBottomDataG.datasets[0].data[0]=$scope.selectedAggregationRecord.green;
            $scope.doughnutChartBottomDataG.datasets[0].data[1]=($scope.selectedAggregationRecord.yellow+$scope.selectedAggregationRecord.red);
            $('.donutVal').text($scope.totalOfDoughnutChart);
            console.log($scope.selectedAggregationRecord.green);
            $('.donutValG').text($scope.selectedAggregationRecord.green);
            $('.donutValY').text($scope.selectedAggregationRecord.yellow);
            $('.donutValR').text($scope.selectedAggregationRecord.red);
            $scope.isDonutValueSet=true;
            $scope.isDonutValueGSet=true;
            if($scope.aggregationsBarGraphData.length>1){
                $scope.previousAggregationRecord.green=$scope.aggregationsBarGraphData[1].G;
                $scope.previousAggregationRecord.yellow=$scope.aggregationsBarGraphData[1].Y;
                $scope.previousAggregationRecord.red=$scope.aggregationsBarGraphData[1].R;
            }

            $scope.aggregationChartType = "bar";
            $scope.aggregationsGraphData = $scope.aggregationsBarGraphData;
            $scope.specialStackedType = "bar";
            //dashboardDataProcessFactory.processAggregationGraph($scope, $scope.aggregationsGraphData);
            dashboardDataProcessFactory.processAggregationGraphData($scope,aggregationsData.graph);

        }
        dashboardDataProcessFactory.procrsssAggegationData($scope, aggregationsData);

        /*if ($scope.processAggregationMasterGraphArr.length > 0) {
         $scope.loadHorizentalGraph($scope.processAggregationMasterGraphArr[$scope.portalMonthSelectedIndex]);
         } else {
         $scope.showErrorMessageDialog(DASH_NO_DATA_FOUND_ERR_MESS);
         }
         usSpinnerService.stop('spinner-1');*/

    }
    dashboardDataProcessFactory.procrsssAggegationData = function ($scope, aggregationsData) {
        var tempIndex = 0;
        $scope.aggregationsBarGraphData = {};
        $scope.aggregationsStackedGraphData = {};
        $scope.aggregationsSpecialStackedGraphData = {};
        $scope.aggregationsGraphData = {};
        $scope.aggregationsApproverArr = [];
        $scope.aggregationsApproverGraphArr = [];
        var i, j;
        $scope.aggregationsStackedGraphData = aggregationsData.dashStackedGraphData;
        $scope.aggregationsBarGraphData = aggregationsData.graph;
        $scope.aggregationsSpecialStackedGraphData = aggregationsData.drillStackedGraphData;
        $scope.tempAggregationsDrillOptionsArr = $scope.aggregationsDrillOptionsArr;
        if ($scope.wsTempParamObj.apiversion == "2.0" || $scope.wsTempParamObj.apiversion == "2.1" || $scope.wsTempParamObj.apiversion == "2.2" || $scope.wsTempParamObj.apiversion == "3.0") {
            if ($scope.drillDownLabelArr.length > 0 && $scope.level == "H0") {
                if ($scope.drillDownLabelArr[1] != undefined && $scope.drillDownLabelArr[1] != "" && $scope.drillDownLabelArr[1] != null) {
                    $scope.optionLabel = $scope.drillDownLabelArr[1];
                } else {
                    $scope.optionLabel = DASH_DRILL_DOWN_LBL;
                }

            }
        } else {
            $scope.optionLabel = DASH_DRILL_DOWN_LBL;
        }
        if (aggregationsData.drillOptions.length > 0) {
            $scope.aggregationsDrillOptionsArr = aggregationsData.drillOptions;
        } else {
            $scope.aggregationsDrillOptionsArr = $scope.tempAggregationsDrillOptionsArr;
            $scope.optionLabel = $scope.selectedDrillDownOption.optionLabel;

        }

        $scope.processAggregationMasterGraphArr = aggregationsData.custom1;
        ///console.log($scope.processAggregationMasterGraphArr);
        dashboardDataProcessFactory.processBreakDownArr($scope.processAggregationMasterGraphArr,$scope);
        ///dashboardDataProcessFactory.processJSON($scope.processAggregationMasterGraphArr,$scope);

        $scope.aggregationsDrillOptionsArr.sort(function (a, b) {
            if (a.optionLabel < b.optionLabel)
                return -1;
            if (a.optionLabel > b.optionLabel)
                return 1;
            return 0;
        });
        $scope.drillDownHierarchyArr[0] = {
            label: $scope.currentClientCofig.drillDownHierarchyLabel,
            level: "H0",
            shortname:$scope.currentClientCofig.drillDownHierarchyLabel,
            id: 0

        };

        if ($scope.selectedDrillDownOption.hierarchy != undefined) {
            if ($scope.aggregationsDrillOptionsArr.length > 0 && $scope.aggregationsDrillOptionsArr[0].hierarchy != $scope.tempAggregationsDrillOptionsArr[0].hierarchy) {
                tempIndex = $scope.selectedDrillDownOption.hierarchy.substring(1, $scope.selectedDrillDownOption.length);
                console.log(tempIndex)
                $scope.drillDownHierarchyArr[tempIndex] = {
                    label: $scope.selectedDrillDownOption.optionLabel,
                    level: $scope.selectedDrillDownOption.hierarchy,
                    shortname:$scope.selectedDrillDownOption.shortname,
                    id: tempIndex
                };

                if ($scope.drillDownLabelArr.length > 0) {
                    if ($scope.drillDownLabelArr[parseInt(tempIndex) + 1] != undefined && $scope.drillDownLabelArr[parseInt(tempIndex) + 1] != "" && $scope.drillDownLabelArr[parseInt(tempIndex) + 1] != null) {
                        $scope.optionLabel = $scope.drillDownLabelArr[parseInt(tempIndex) + 1];
                    } else {
                        $scope.optionLabel = DASH_DRILL_DOWN_LBL;
                    }
                }
            }

        }
    }




    /* /!* process the Aggregations WS API*!/
     dashboardDataProcessFactory.processAggregationsData = function ($scope, aggregationsData) {
     console.log($scope.aggregationsGraphData);
     $scope.aggregationsBarGraphData = aggregationsData.graph;
     var total=$scope.aggregationsBarGraphData[0].R+$scope.aggregationsBarGraphData[0].G+$scope.aggregationsBarGraphData[0].Y;

     //Show last month's data value on first page
     $scope.doughnutChartData.datasets[0].data[0]=$scope.selectedAggregationRecord.red=$scope.aggregationsBarGraphData[0].R;
     $scope.doughnutChartData.datasets[0].data[1]=$scope.selectedAggregationRecord.green=$scope.aggregationsBarGraphData[0].G;
     $scope.doughnutChartData.datasets[0].data[2]=$scope.selectedAggregationRecord.yellow=$scope.aggregationsBarGraphData[0].Y;
     $scope.doughnutChartBottomDataY.datasets[0].data[0]=$scope.selectedAggregationRecord.yellow;
     $scope.doughnutChartBottomDataY.datasets[0].data[1]=($scope.selectedAggregationRecord.green+$scope.selectedAggregationRecord.red);
     $scope.doughnutChartBottomDataR.datasets[0].data[0]=$scope.selectedAggregationRecord.red;
     $scope.doughnutChartBottomDataR.datasets[0].data[1]=($scope.selectedAggregationRecord.yellow+$scope.selectedAggregationRecord.green);
     $scope.doughnutChartBottomDataG.datasets[0].data[0]=$scope.selectedAggregationRecord.green;
     $scope.doughnutChartBottomDataG.datasets[0].data[1]=($scope.selectedAggregationRecord.yellow+$scope.selectedAggregationRecord.red);
     $('.donutVal').text(total);
     $('.donutValG').text($scope.selectedAggregationRecord.green);
     $('.donutValY').text($scope.selectedAggregationRecord.yellow);
     $('.donutValR').text($scope.selectedAggregationRecord.red);
     $scope.isDonutValueSet=true;
     $scope.isDonutValueGSet=true;
     if($scope.aggregationsBarGraphData.length>1){
     $scope.previousAggregationRecord.green=$scope.aggregationsBarGraphData[1].G;
     $scope.previousAggregationRecord.yellow=$scope.aggregationsBarGraphData[1].Y;
     $scope.previousAggregationRecord.red=$scope.aggregationsBarGraphData[1].R;
     }
     //doughnutChartObj.update();
     dashboardDataProcessFactory.processAggregationGraphData($scope,aggregationsData.graph);
     dashboardDataProcessFactory.processHierarchyData($scope,aggregationsData.drillOptions);

     }*/
    //Handle drill down hierarchy
    dashboardDataProcessFactory.processHierarchyData=function($scope,drillOptions){
        $scope.drillDownHierarchyArr[0] = {
            label: $scope.currentClientCofig.drillDownHierarchyLabel,
            level: "H0",
            id: 0
        };
        $scope.menuJSON.Hierarchy[$scope.drillDownOptionSelectedIndex].data=[];
        $scope.menuJSON.Hierarchy[$scope.drillDownOptionSelectedIndex].shortName=[];
        for(var h in drillOptions){
            $scope.menuJSON.Hierarchy[$scope.drillDownOptionSelectedIndex].data[h]=drillOptions[h].optionLabel;
            $scope.menuJSON.Hierarchy[$scope.drillDownOptionSelectedIndex].shortName[h]=drillOptions[h].shortname;
        }
        /*if(!$scope.$$phase) {
         $scope.$digest();
         }*/
    }
    dashboardDataProcessFactory.processAggregationGraphData=function($scope,graphData){
        var lastTwelveMonthsGraphData
        if(graphData.length>12){
            lastTwelveMonthsGraphData =graphData.slice(0,12);
        }
        else{
            lastTwelveMonthsGraphData=graphData;
        }
        var graphTargetValueArr=dashboardDataProcessFactory.createArrayObjectValues(lastTwelveMonthsGraphData,'G');
        var graphCurrentValueArr=dashboardDataProcessFactory.createArrayObjectValues(lastTwelveMonthsGraphData,'Y');
        var graphMinValueArr=dashboardDataProcessFactory.createArrayObjectValues(lastTwelveMonthsGraphData,'R');
        var graphInterval=dashboardDataProcessFactory.createArrayObjectValues(lastTwelveMonthsGraphData,'interval');
        $scope.aggregatedGraphAllRecords.target=graphTargetValueArr=graphTargetValueArr.reverse();
        $scope.aggregatedGraphAllRecords.current=graphCurrentValueArr=graphCurrentValueArr.reverse();
        $scope.aggregatedGraphAllRecords.min=graphMinValueArr=graphMinValueArr.reverse();
        $scope.aggregatedGraphAllRecords.interval=graphInterval=graphInterval.reverse();
        $scope.selectedAggregationRecord.interval=$scope.aggregatedGraphAllRecords.interval[$scope.aggregatedGraphAllRecords.interval.length-1];
        $scope.aggregationsMonthsArr=graphInterval;
        var flktyAggrData = Flickity.data('.demo__slides');
        /*if(lastTwelveMonthsGraphData.length>6){
         $scope.showJulToDec();

         $scope.flickityOptions.initialIndex=1;
         $scope.isAggregationButtonVisible=true;
         console.log(flktyAggrData)
         flktyAggrData.bindDrag();
         $scope.graphMinValueArr.firstHalf=graphMinValueArr.slice(0,(graphMinValueArr.length/2));
         $scope.graphMinValueArr.secondHalf=graphMinValueArr.slice((graphMinValueArr.length/2));
         $scope.graphCurrentValueArr.firstHalf=graphCurrentValueArr.slice(0,(graphCurrentValueArr.length/2));
         $scope.graphCurrentValueArr.secondHalf=graphCurrentValueArr.slice((graphCurrentValueArr.length/2));
         $scope.graphTargetValueArr.firstHalf=graphTargetValueArr.slice(0,(graphTargetValueArr.length/2));
         $scope.graphTargetValueArr.secondHalf=graphTargetValueArr.slice((graphTargetValueArr.length/2));
         var monthsLabelFirstHalf=$scope.aggregationsMonthsArr.slice(0,($scope.aggregationsMonthsArr.length/2));
         var monthsLabelSecondHalf=$scope.aggregationsMonthsArr.slice(($scope.aggregationsMonthsArr.length/2));
         $scope.aggregationsDateArr=[];
         $scope.barChartData.labels=dashboardDataProcessFactory.formatMonthDate($scope,monthsLabelFirstHalf);
         $scope.barChartDataLastMonth.labels=dashboardDataProcessFactory.formatMonthDate($scope,monthsLabelSecondHalf);
         $scope.aggregationsDateArr=$scope.aggregationsDateArr.reverse();
         $scope.portalMonthSelectedIndex=0;
         $scope.aggregationsSelectedDate=$scope.aggregationsDateArr[$scope.portalMonthSelectedIndex];
         $scope.btnLabelbar.firstHalf=$scope.generateDisplayLabelButton($scope.barChartData.labels);
         $scope.btnLabelbar.secondHalf=$scope.generateDisplayLabelButton($scope.barChartDataLastMonth.labels);

         }
         else{*/
        $scope.flickityOptions.initialIndex=0;
        // $scope.showJanToJun();
        $scope.isAggregationButtonVisible=false;
        /* flktyAggrData.unbindDrag();*/
        $scope.graphMinValueArr.firstHalf=graphMinValueArr;
        $scope.graphCurrentValueArr.firstHalf=graphCurrentValueArr;
        $scope.graphTargetValueArr.firstHalf=graphTargetValueArr;
        $scope.graphTargetValueArr.secondHalf=$scope.barChartDataLastMonth.labels=$scope.graphCurrentValueArr.secondHalf=$scope.graphMinValueArr.secondHalf=[];
        $scope.aggregationsDateArr=[];
        $scope.barChartData.labels=dashboardDataProcessFactory.formatMonthDate($scope,$scope.aggregationsMonthsArr);
        $scope.aggregationsDateArr=$scope.aggregationsDateArr.reverse();
        ///$scope.portalMonthSelectedIndex=0;
        $scope.aggregationsSelectedDate=$scope.aggregationsDateArr[$scope.portalMonthSelectedIndex];
        $scope.btnLabelbar.firstHalf=$scope.barChartData.labels[0][0]+" "+$scope.barChartData.labels[0][1]+" - "+$scope.barChartData.labels[$scope.barChartData.labels.length-1][0]+" "+$scope.barChartData.labels[$scope.barChartData.labels.length-1][1];
        /*}*/
    }
    //sorting comments based on Date
    dashboardDataProcessFactory.sortDataByDate = function (data, prop) {
        data.sort(function(a,b){
            var c = new Date(a[prop]);
            var d = new Date(b[prop]);
            return c- d;
        });

        return data;
    }
    dashboardDataProcessFactory.createArrayObjectValues = function(items, prop){
        var arr=[];
        return items.reduce( function(a, b){
            arr.push(b[prop])
            return arr;
        }, 0);
    };
    dashboardDataProcessFactory.formatMonthDate = function($scope,DateArr){
        var monthNames = ["","Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        console.log(DateArr);
        var formattedDate=[]
        for(var d in DateArr){
            var arr=[];
            var year =DateArr[d].toString().split("").slice(0,4).join("");
            var month=DateArr[d].toString().split("").slice(4).join("");
            if(month<10){
                month=month.toString().split("").slice(1).join("");
            }
            $scope.aggregationsDateArr.push(monthNames[month]+" "+year);
            arr.push(monthNames[month]);
            arr.push(year);
            /*console.log(month+" "+year);*/
            formattedDate[d]=arr
        }
        return formattedDate;
    };
    dashboardDataProcessFactory.processDrillThroughMetricData = function ($scope, aggregationsMetricData) {
        /*alert('Success');*/
        if(!$scope.isCardViewVisible){
            if(aggregationsMetricData.length>5){
                $('.view-record').text("1 - "+$scope.listViewNumberOfRecords);
            }
            else{
                $('.view-record').text("1 - " +aggregationsMetricData.length);
            }
        }
        else{
            if(aggregationsMetricData.length>4){
                $('.view-record').text("1 - 4");
            }
            else{
                $('.view-record').text("1 - " +aggregationsMetricData.length);
            }
        }


        var i = 0;
        if (aggregationsMetricData.length > 0) {

            for (i = 0; i < aggregationsMetricData.length; i++) {
                if ($scope.wsTempParamObj.apiversion == "2.0" || $scope.wsTempParamObj.apiversion == "2.1" || $scope.wsTempParamObj.apiversion == "2.2" || $scope.wsTempParamObj.apiversion == "3.0") {

                    $scope.aggregationsMetricMasterArr.push({
                        metricName: aggregationsMetricData[i].metricName,
                        metricKey: aggregationsMetricData[i].metricKey,
                        target: utilityService.formatMetricDataTypes(aggregationsMetricData[i].target, aggregationsMetricData[i].metricType,$scope.wsTempParamObj.clientName),
                        min: utilityService.formatMetricDataTypes(aggregationsMetricData[i].min, aggregationsMetricData[i].metricType,$scope.wsTempParamObj.clientName),
                        actual: utilityService.formatMetricDataTypes(aggregationsMetricData[i].actual, aggregationsMetricData[i].metricType,$scope.wsTempParamObj.clientName),
                        status: aggregationsMetricData[i].status,
                        trend: aggregationsMetricData[i].trend,
                        metricType: aggregationsMetricData[i].metricType,
                        factKey: aggregationsMetricData[i].factKey,
                        commentCount: aggregationsMetricData[i].commentCount,
                        h1label: aggregationsMetricData[i].h1label,
                        h2label: aggregationsMetricData[i].h2label,
                        h3label: aggregationsMetricData[i].h3label,
                        h4label: aggregationsMetricData[i].h4label,
                        h5label: aggregationsMetricData[i].h5label,
                        processName: aggregationsMetricData[i].breakdownName,
                        selected: false,
                        trendDiff : aggregationsMetricData[i].trendDiff
                    });


                } else {
                    $scope.aggregationsMetricMasterArr.push({
                        metricName: aggregationsMetricData[i].metricName,
                        metricKey: aggregationsMetricData[i].metricKey,
                        target: utilityService.formatMetricDataTypes(aggregationsMetricData[i].target, aggregationsMetricData[i].metricType,$scope.wsTempParamObj.clientName),
                        min: utilityService.formatMetricDataTypes(aggregationsMetricData[i].min, aggregationsMetricData[i].metricType,$scope.wsTempParamObj.clientName),
                        actual: utilityService.formatMetricDataTypes(aggregationsMetricData[i].actual, aggregationsMetricData[i].metricType,$scope.wsTempParamObj.clientName),
                        status: aggregationsMetricData[i].status,
                        trend: aggregationsMetricData[i].trend.split("|")[0],
                        metricType: aggregationsMetricData[i].metricType,
                        factKey: aggregationsMetricData[i].trend.split("|")[1],
                        commentCount: aggregationsMetricData[i].trend.split("|")[2],
                        clientGeo: aggregationsMetricData[i].trend.split("|")[3],
                        clientCountry: aggregationsMetricData[i].trend.split("|")[4],
                        processName: aggregationsMetricData[i].trend.split("|")[5]

                    });

                }
            }
            console.log($scope.aggregationsMetricMasterArr);

            var sum = aggregationsMetricMasterArr.reduce(function(a, b) { return a + b; }, 0);
            for(var i=0;i<aggregationsMetricMasterArr.length;i++){
                aggregationsMetricMasterArr[i] = (aggregationsMetricMasterArr[i].trendDiff)*100;
            }

            console.log(aggregationsMetricMasterArr);
            //var res = $scope.aggregationsMetricMasterArr[0].trendDiff*100;
            //console.log(res);

            /* $scope.aggregationsSelectedDate = $scope.aggregationsDatesArr[$scope.portalMonthSelectedIndex];*/

        } else {
            $scope.showErrorModal(DASH_NO_DATA_FOUND_ERR_MESS);
        }
    }
    dashboardDataProcessFactory.processDrillDownGraph = function ($scope, arr) {
        //console.log(arr);
        $scope.portalAllMetricGroupRecords = [];
        try {

            for (i = 0; i < arr.length; i++) {
                for (j = 0; j < arr[i].facts.length; j++) {
                    var year = String(arr[i].facts[j].interval).substring(0, String(arr[i].facts[j].interval).length - 2);
                    var month = String(arr[i].facts[j].interval).substring(String(arr[i].facts[j].interval).length - 2, String(arr[i].facts[j].interval).length);
                    var timestamp = utilityService.convertToTimeStamp(parseInt(year), parseInt(month), 15, 16, 0, 0);
                    $scope.portalAllMetricGroupRecords.push({
                        metricKey: arr[i].metricKey,
                        factKey: arr[i].facts[j].factKey,
                        metricGroupName: utilityService.removeSpecialCharacter(arr[i].metricGroupName),
                        target: utilityService.formatMetricGraphData(arr[i].facts[j].target, arr[i].valueType),
                        current: utilityService.formatMetricGraphData(arr[i].facts[j].current, arr[i].valueType),
                        min: utilityService.formatMetricGraphData(arr[i].facts[j].min, arr[i].valueType),
                        status: arr[i].facts[j].status,
                        trend: arr[i].facts[j].trend,
                        timestamp: timestamp,
                        displayDate: utilityService.convertToYearMonthFormat(timestamp),
                        comments: arr[i].facts[j].comments

                    });

                }
            }
            $scope.portalAllMetricGroupRecords = $scope.portalAllMetricGroupRecords.sort(function (a, b) {
                if (a.timestamp > b.timestamp) {
                    return 1;
                }
                if (a.timestamp < b.timestamp) {
                    return -1;
                }
                // a must be equal to b
                return 0;
            });

            if ($scope.portalAllMetricGroupRecords.length > 0 && $scope.selectedChartPointIndex != -1) {

                if ($scope.isCommentAdded) {
                    if ($scope.selectedChartPointIndex == 0) {
                        $scope.selectedChartPointIndex = $scope.portalLastTwelveMetricGroupRecords.length-1;
                    }
                    $scope.selectedGraphRecord = $scope.portalLastTwelveMetricGroupRecords[$scope.selectedChartPointIndex];
                    $scope.loadDrillDownChart($scope.portalAllMetricGroupRecords);
                    this.processCommentsData($scope,$scope.portalLastTwelveMetricGroupRecords[$scope.selectedChartPointIndex].comments);

                }
                else{
                    $scope.selectedChartPointIndex=$scope.portalAllMetricGroupRecords.length - 1;
                    $scope.selectedGraphRecord = $scope.portalAllMetricGroupRecords[$scope.portalAllMetricGroupRecords.length - 1];
                    $scope.loadDrillDownChart($scope.portalAllMetricGroupRecords);
                    this.processCommentsData($scope,$scope.portalLastTwelveMetricGroupRecords[$scope.portalLastTwelveMetricGroupRecords.length-1].comments);
                }

            }
            //console.log($scope.portalAllMetricGroupRecords);

            console.log($scope.portalLastTwelveMetricGroupRecords[$scope.portalLastTwelveMetricGroupRecords.length-1].comments);
        } catch (error) {
            $scope.graphDataError = true;
        }
    }
    //process the comment data
    dashboardDataProcessFactory.processCommentsData = function ($scope, arr) {
        $scope.selectedSLACommentArr = [];
        try {
            for (var i = 0; i < arr.length; i++) {
                if (arr[i].commentTimestamp != null) {
                    $scope.selectedSLACommentArr = arr;
                }
            }
        } catch (error) {
            console.log(error)
        }

    }

    dashboardDataProcessFactory.processBreakDownArr=function(dataArr,$scope){
        ////$scope.aggregationsProcessArr=[];
        for(var i=0;i<dataArr.length;i++){
            $scope.headerLabel=dataArr[1].header
            for(var j=0;j<dataArr[$scope.portalMonthSelectedIndex].data.length;j++){
                ///console.log(dataArr[i].data[j].H3);
                $scope.aggregationsProcessArr.push(dataArr[$scope.portalMonthSelectedIndex].data[j].H3);
            }
        }
        $scope.aggregationsProcessArr.unshift($scope.headerLabel + " " + DASH_ALL_LBL);
        if($scope.portalProcessSelectedIndex==0){
            $scope.processValue=$scope.headerLabel + " " + DASH_ALL_LBL;
        }
        //remove duplicates values from array
        $scope.aggregationsProcessArr = $scope.aggregationsProcessArr.filter(function (item, i, ar) {
            return ar.indexOf(item) === i;
        });
        ///$scope.processValue=$scope.headerLabel + " " + DASH_ALL_LBL;
        console.log( $scope.aggregationsProcessArr )
    }
    dashboardDataProcessFactory.processJSON=function(dataArr,$scope){
        console.log($scope.portalMonthSelectedIndex);
        console.log(dataArr[$scope.portalMonthSelectedIndex].data.length);
        var tempArr=new Array();
        $scope.treemapDataArr=[];

        for(var i=0;i<dataArr[$scope.portalMonthSelectedIndex].data.length;i++){
            for(var j=0;j<dataArr[$scope.portalMonthSelectedIndex].data[i].treemapdata.length;j++) {
                console.log(dataArr[$scope.portalMonthSelectedIndex].data[i].treemapdata[j].name)
                if($scope.processValue==dataArr[$scope.portalMonthSelectedIndex].data[i].treemapdata[j].name){
                    tempArr[0]={name:dataArr[$scope.portalMonthSelectedIndex].data[i].treemapdata[j].name,children:dataArr[$scope.portalMonthSelectedIndex].data[i].treemapdata[j].children};
                }else if($scope.processValue==$scope.headerLabel + " " + DASH_ALL_LBL){
                    tempArr[i]={name:dataArr[$scope.portalMonthSelectedIndex].data[i].treemapdata[j].name,children:dataArr[$scope.portalMonthSelectedIndex].data[i].treemapdata[j].children};
                }

            }
        }
        $scope.treemapDataArr={name:"Global",children:tempArr};

        $("#svgContent").empty();
        //$("#treemapContent").appendChild('<svg width="500" height="300"></svg>');
        var svg = d3.select("svg"),
            width = +svg.attr("width"),
            height = +svg.attr("height");

        var fader = function(color) { return d3.interpolateRgb(color, "#fff")(0.2); },
            color = d3.scaleOrdinal(d3.schemeCategory20.map(fader)),
            format = d3.format(",d");

        var treemap = d3.treemap()
            .tile(d3.treemapResquarify)
            .size([width, height])
            .round(true)
            .paddingInner(1);

        var dummydata={
            "name": "flare",
            "children": [
                {
                    "name": "analytics",
                    "children": [
                        {
                            "name": "cluster",
                            "children": [
                                {"name": "Green00", "size": 100},
                                {"name": "Red00", "size":80 },
                                {"name": "Yellow00", "size": 0}
                            ]
                        },
                        {
                            "name": "optimizationsdsdsdsdssssssssssss",
                            "children": [
                                {"name": "Green11", "size": 100},
                                {"name": "Red11", "size":80 },
                                {"name": "Yellow11", "size": 60}
                            ]
                        },
                        {
                            "name": "optimizationsdsd",
                            "children": [
                                {"name": "Green22", "size": 100},
                                {"name": "Red22", "size":80 },
                                {"name": "Yellow22", "size": 60}
                            ]
                        }
                    ]
                }
            ]
        }
        console.log(dummydata);

        console.log($scope.treemapDataArr);
        //$scope.treemapDataArr;
        var data=$scope.treemapDataArr;
        var root = d3.hierarchy(data)
            .eachBefore(function(d) { d.data.id = (d.parent ? d.parent.data.id + "." : "") + d.data.name; })
            .sum(sumBySize)
            .sort(function(a, b) { return b.height - a.height || b.value - a.value; });

        treemap(root);

        var cell = svg.selectAll("g")
            .data(root.leaves())
            .enter().append("g")
            .attr("transform", function(d) { return "translate(" + d.x0 + "," + d.y0 + ")"; });

        cell.append("rect")
            .attr("id", function(d) { return d.data.id; })
            .attr("width", function(d) { return d.x1 - d.x0; })
            .attr("height", function(d) { return d.y1 - d.y0; })
            .attr("fill", function(d) { return color(d.parent.data.id); })
            .text(function(d,i) { return d; });

        cell.append("clipPath")
            .attr("id", function(d) { return "clip-" + d.data.id; })
            .append("use")
            .attr("xlink:href", function(d) { return "#" + d.data.id; });

        cell.append("text")
            .attr("clip-path", function(d,i) { return "url(#clip-" + d.data.id + ")"; })
            .selectAll("tspan")
            .data(function(d,i) {  console.log(i);return d.data.name.split(/(?=[A-Z][^A-Z])/g); })
            .enter().append("tspan")
            .attr("x", 4)
            .attr("y", function(d, i) { return 13 + i * 10; })
            .text(function(d,i) { return d; });

        cell.append("title")
            .text(function(d) { return d.data.id + "\n" + format(d.value); });
        console.log(cell)

        d3.selectAll("input")
            .data([sumBySize, sumByCount], function(d) { return d ? d.name : this.value; })
            .on("change", changed);

        var timeout = d3.timeout(function() {
            d3.select("input[value=\"sumByCount\"]")
                .property("checked", true)
                .dispatch("change");
        }, 2000);

        function changed(sum) {
            timeout.stop();

            treemap(root.sum(sum));

            cell.transition()
                .duration(750)
                .attr("transform", function(d) { return "translate(" + d.x0 + "," + d.y0 + ")"; })
                .select("rect")
                .attr("width", function(d) { return d.x1 - d.x0; })
                .attr("height", function(d) { return d.y1 - d.y0; });
        }


        function sumByCount(d) {
            return d.size;
        }

        function sumBySize(d) {
            return d.size;
        }


    }

    dashboardDataProcessFactory.processTreeMapData=function($scope,dataArr){
        console.log(dataArr);
        var root={};
        var margin = {top: 0, right: 0, bottom: 0, left: 0},
            width = 410,
            height = 245 - margin.top - margin.bottom,
            formatNumber = d3.format(",d"),
            transitioning;

        var x = d3.scale.linear()
            .domain([0, width])
            .range([0, width]);
        function colores_google(n) {
            var colores_g = ["#3366cc", "#dc3912", "#ff9900", "#109618", "#990099", "#0099c6", "#dd4477", "#66aa00", "#b82e2e", "#316395", "#994499", "#22aa99", "#aaaa11", "#6633cc", "#e67300", "#8b0707", "#651067", "#329262", "#5574a6", "#3b3eac"];
            return colores_g[n % colores_g.length];
        }
        var color = d3.scale.category20c();
        console.log(d3.scale.category20c().range());
        var y = d3.scale.linear()
            .domain([0, height])
            .range([0, height]);

        var treemap = d3.layout.treemap()
            .children(function(d, depth) { return depth ? null : d._children; })
            .sort(function(a, b) { return a.value - b.value; })
            .ratio(height / width * 0.5 * (1 + Math.sqrt(5)))
            .round(false);
        $("#chart").empty();
        var svg = d3.select("#chart").append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.bottom + margin.top)
            .style("margin-left", -margin.left + "px")
            .style("margin.right", -margin.right + "px")
            .append("g")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
            .style("shape-rendering", "crispEdges");

        var grandparent = svg.append("g")
            .attr("class", "grandparent");

        /*grandparent.append("rect")
         .attr("y", -margin.top)
         .attr("width", width)
         .attr("height", margin.top);

         grandparent.append("text")
         .attr("x", 6)
         .attr("y", 6 - margin.top)
         .attr("dy", ".35em");*/


        root=dataArr;
        console.log(root);
        initialize(root);
        accumulate(root);
        layout(root);
        display(root);

        function initialize(root) {
            root.x = root.y = 0;
            root.dx = width;
            root.dy = height;
            root.depth = 0;
        }

        // Aggregate the values for internal nodes. This is normally done by the
        // treemap layout, but not here because of our custom implementation.
        // We also take a snapshot of the original children (_children) to avoid
        // the children being overwritten when when layout is computed.
        function accumulate(d) {

            return (d._children = d.children)
                ? d.value = d.children.reduce(function(p, v) { return p + accumulate(v); }, 0)
                : d.value;
        }

        // Compute the treemap layout recursively such that each group of siblings
        // uses the same size (1×1) rather than the dimensions of the parent cell.
        // This optimizes the layout for the current zoom state. Note that a wrapper
        // object is created for the parent node for each group of siblings so that
        // the parent’s dimensions are not discarded as we recurse. Since each group
        // of sibling was laid out in 1×1, we must rescale to fit using absolute
        // coordinates. This lets us use a viewport to zoom.
        function layout(d) {
            if (d._children) {
                treemap.nodes({_children: d._children});
                d._children.forEach(function(c) {
                    c.x = d.x + c.x * d.dx;
                    c.y = d.y + c.y * d.dy;
                    c.dx *= d.dx;
                    c.dy *= d.dy;
                    c.parent = d;
                    layout(c);
                });
            }
        }

        function display(d) {
            grandparent
                .datum(d.parent)
                .on("click", transition)
                .select("text")
                .text(name(d));

            var g1 = svg.insert("g", ".grandparent")
                .datum(d)
                .attr("class", "depth");

            var g = g1.selectAll("g")
                .data(d._children)
                .enter().append("g");

            g.filter(function(d) { return d._children; })
                .classed("children", true)
            //.on("click", transition);
            g.selectAll(".child")

                .data(function(d) { return d._children || [d]; })
                .enter().append("rect").style("animation", function(d,i){return "hideshow "+(i+1)+"s ease-out"}).style("fill", function(d) {
                    for(var i=0;i<d._children.length;i++){
                        if(d._children[i].name.indexOf("G:")!=-1){
                            return "#008A52";
                        }else if(d._children[i].name.indexOf("R:")!=-1){
                            return "#D9182D";
                        }else if(d._children[i].name.indexOf("Y:")!=-1){
                            return "#FFCF01";
                        }
                    }
                    return color(d.color);
                })
                .call(rect)

                .style("cursor","pointer")
                .on("load",transition)
                .on("click", function(d){alert(d.parent.name+"<>"+d.name)})


            g.append("rect")
                .attr("class", "children")
                .call(rect)

                .append("title")

                .text(function(d) { return formatNumber(d.value); });

            g.append("text")
                .attr("dy", ".75em")
                .text(function(d) { return d.name; })
                .call(text);

            function transition(d) {
                console.log(d3.scale.category20c().range());
                if (transitioning || !d) return;
                transitioning = true;

                var g2 = display(d),
                    t1 = g1.transition().duration(750),
                    t2 = g2.transition().duration(750);

                // Update the domain only after entering new elements.
                x.domain([d.x, d.x + d.dx]);
                y.domain([d.y, d.y + d.dy]);

                // Enable anti-aliasing during the transition.
                svg.style("shape-rendering", null);

                // Draw child nodes on top of parent nodes.
                svg.selectAll(".depth").sort(function(a, b) { return a.depth - b.depth; });

                // Fade-in entering text.
                g2.selectAll("text").style("fill-opacity", 0);

                // Transition to the new view.
                t1.selectAll("text").call(text).style("fill-opacity", 0);
                t2.selectAll("text").call(text).style("fill-opacity", 1);
                t1.selectAll("rect").call(rect);
                t2.selectAll("rect").call(rect);


                // Remove the old node when the transition is finished.
                t1.remove().each("end", function() {
                    svg.style("shape-rendering", "crispEdges");
                    transitioning = false;
                });
            }

            return g;
        }

        function text(text) {
            text.attr("x", function(d) { return x(d.x) + 6; })
                .attr("y", function(d) { return y(d.y) + 6; });
        }

        function rect(rect) {
            rect.attr("x", function(d) { return x(d.x); })
                .attr("y", function(d) { return y(d.y); })
                .attr("width", function(d) { return x(d.x + d.dx) - x(d.x); })
                .attr("height", function(d) { return y(d.y + d.dy) - y(d.y); });
        }

        function name(d) {
            return d.parent
                ? name(d.parent) + " / " + d.name
                : d.name;
        }

    }
    return dashboardDataProcessFactory;
});