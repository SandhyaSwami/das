/**
 * Created by vaibhav_parkhi on 10/15/2015.
 */
location_macro.service('portalservice', ['$http', function(http) {

    ///New API for all months data
    this.getTrendedMetricData=function(wsParamObj,currentDeploymentEnv){
        var serviceURL = constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_TRENDED+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&clientGeo="+cleanURL(currentDeploymentEnv,wsParamObj.clientGeo)+"&clientCountry="+cleanURL(currentDeploymentEnv,wsParamObj.clientCountry)+"&dataType="+cleanURL(currentDeploymentEnv,wsParamObj.dataType)+"&dateType="+cleanURL(currentDeploymentEnv,wsParamObj.dateType);
        var config ={method: 'GET',url: serviceURL,headers: {'API_VERSION': wsParamObj.apiversion},data: {}};
        console.log("serviceURL ----------------:" + serviceURL);
        return  http(config);
    }

    this.getMetricsData = function(wsParamObj,currentDeploymentEnv)
    {

        var serviceURL = constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_METRICS+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&clientGeo="+cleanURL(currentDeploymentEnv,wsParamObj.clientGeo)+"&clientCountry="+cleanURL(currentDeploymentEnv,wsParamObj.clientCountry)+"&dataType="+cleanURL(currentDeploymentEnv,wsParamObj.dataType)+"&dateType="+cleanURL(currentDeploymentEnv,wsParamObj.dateType)+"&startDate="+wsParamObj.startDate;
        var config ={method: 'GET',url: serviceURL,headers: {'API_VERSION': wsParamObj.apiversion},data: {}};
        console.log("serviceURL :" + serviceURL);
        return  http(config);

    }

    this.getAggregationsData = function(wsParamObj,currentDeploymentEnv)
    {

        var serviceURL = "";
        console.log(wsParamObj.apiversion);
        if(wsParamObj.apiversion==2.2 || wsParamObj.apiversion==3.0){
            serviceURL=constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_AGGREGATION+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&hierarchyPath="+cleanURL(currentDeploymentEnv,wsParamObj.hierarchyPath)+"&aggregationType="+cleanURL(currentDeploymentEnv,wsParamObj.aggregationType)+"&dataType="+cleanURL(currentDeploymentEnv,wsParamObj.dataType)+"&intervalType="+cleanURL(currentDeploymentEnv,wsParamObj.dateType)+"&breakDownFilter="+cleanURL(currentDeploymentEnv,wsParamObj.breakDownFilter)+"&dynamic=true";
        }else{
            serviceURL=constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_AGGREGATION+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&hierarchyPath="+cleanURL(currentDeploymentEnv,wsParamObj.hierarchyPath)+"&aggregationType="+cleanURL(currentDeploymentEnv,wsParamObj.aggregationType)+"&dataType="+cleanURL(currentDeploymentEnv,wsParamObj.dataType)+"&intervalType="+cleanURL(currentDeploymentEnv,wsParamObj.dateType)+"&dynamic=true";
        }
        //var serviceURL2 = constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_AGGREGATION+"clientName="+cleanURL(wsParamObj.clientName)+"&hierarchyPath="+cleanURL(wsParamObj.hierarchyPath)+"&aggregationType="+cleanURL(wsParamObj.aggregationType)+"&dataType="+cleanURL(wsParamObj.dataType)+"&intervalType="+cleanURL(wsParamObj.dateType);
        ///var serviceURL = constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_AGGREGATION+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&hierarchyPath="+cleanURL(currentDeploymentEnv,wsParamObj.hierarchyPath)+"&aggregationType="+cleanURL(currentDeploymentEnv,wsParamObj.aggregationType)+"&dataType="+cleanURL(currentDeploymentEnv,wsParamObj.dataType)+"&intervalType="+cleanURL(currentDeploymentEnv,wsParamObj.dateType)+"&dynamic=true";
        //var serviceURL = "http://localhost:8080/gps_operational_api"+currentDeploymentEnv.DBD_EXTRAPARAM_AGGREGATION+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&hierarchyPath="+cleanURL(currentDeploymentEnv,wsParamObj.hierarchyPath)+"&aggregationType="+cleanURL(currentDeploymentEnv,wsParamObj.aggregationType)+"&dataType="+cleanURL(currentDeploymentEnv,wsParamObj.dataType)+"&intervalType="+cleanURL(currentDeploymentEnv,wsParamObj.dateType)+"&dynamic=true";
        //var serviceURL = "http://9.3.68.40:11111/gps_operational_api/microsite/aggregations?clientName=Pepsico&hierarchyPath=H1%3AAMEA&aggregationType=COUNT&dataType=SLA&intervalType=monthly";//constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_METRICS+"clientName="+cleanURL(wsParamObj.clientName)+"&clientGeo="+cleanURL(wsParamObj.clientGeo)+"&clientCountry="+cleanURL(wsParamObj.clientCountry)+"&dataType="+cleanURL(wsParamObj.dataType)+"&dateType="+cleanURL(wsParamObj.dateType)+"&startDate="+wsParamObj.startDate;
        var config ={method: 'GET',url: serviceURL,headers: {'API_VERSION': wsParamObj.apiversion},data: {}};
        console.log("serviceURL ............. :" + serviceURL);
        return  http(config);

    }

    this.getFullHierarchy=function(wsParamObj,currentDeploymentEnv){
        var serviceURL = constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_FULLHIERARCHY+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&hierarchyPath="+cleanURL(currentDeploymentEnv,wsParamObj.hierarchyPath)+"&aggregationType="+cleanURL(currentDeploymentEnv,wsParamObj.aggregationType)+"&dataType="+cleanURL(currentDeploymentEnv,wsParamObj.dataType)+"&intervalType="+cleanURL(currentDeploymentEnv,wsParamObj.dateType)+"&breakDownFilter="+cleanURL(currentDeploymentEnv,wsParamObj.breakDownFilter)+"&dynamic=true";
        //var serviceURL = "http://9.3.68.40:11111/gps_operational_api/microsite/aggregations?clientName=Pepsico&hierarchyPath=H1%3AAMEA&aggregationType=COUNT&dataType=SLA&intervalType=monthly";//constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_METRICS+"clientName="+cleanURL(wsParamObj.clientName)+"&clientGeo="+cleanURL(wsParamObj.clientGeo)+"&clientCountry="+cleanURL(wsParamObj.clientCountry)+"&dataType="+cleanURL(wsParamObj.dataType)+"&dateType="+cleanURL(wsParamObj.dateType)+"&startDate="+wsParamObj.startDate;
        var config ={method: 'GET',url: serviceURL,headers: {'API_VERSION': wsParamObj.apiversion},data: {}};
        console.log("serviceURL getDrillThroughMetricData :" + serviceURL);
        return  http(config);
    }

    this.getHierarchyCommentListData=function(wsParamObj,currentDeploymentEnv){
        var serviceURL = constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_HIERARCHY_COMMENT_LIST+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&hierarchyPath="+cleanURL(currentDeploymentEnv,wsParamObj.hierarchyPath)+"&aggregationType="+cleanURL(currentDeploymentEnv,wsParamObj.aggregationType)+"&dataType="+cleanURL(currentDeploymentEnv,wsParamObj.dataType)+"&intervalType="+cleanURL(currentDeploymentEnv,wsParamObj.dateType)+"&breakDownFilter="+cleanURL(currentDeploymentEnv,wsParamObj.breakDownFilter)+"&dynamic=true";
        //var serviceURL = "http://9.3.68.40:11111/gps_operational_api/microsite/aggregations?clientName=Pepsico&hierarchyPath=H1%3AAMEA&aggregationType=COUNT&dataType=SLA&intervalType=monthly";//constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_METRICS+"clientName="+cleanURL(wsParamObj.clientName)+"&clientGeo="+cleanURL(wsParamObj.clientGeo)+"&clientCountry="+cleanURL(wsParamObj.clientCountry)+"&dataType="+cleanURL(wsParamObj.dataType)+"&dateType="+cleanURL(wsParamObj.dateType)+"&startDate="+wsParamObj.startDate;
        var config ={method: 'GET',url: serviceURL,headers: {'API_VERSION': wsParamObj.apiversion},data: {}};
        console.log("serviceURL getDrillThroughMetricData :" + serviceURL);
        return  http(config);
    }
    this.getDrillThroughMetricData=function(wsParamObj,currentDeploymentEnv){
        /*var serviceURL = constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_DRILLTHROUGH+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&hierarchyPath="+cleanURL(currentDeploymentEnv,wsParamObj.hierarchyPath)+"&status="+cleanURL(currentDeploymentEnv,wsParamObj.status)+"&dataType="+cleanURL(currentDeploymentEnv,wsParamObj.dataType)+"&dateRange="+wsParamObj.dateRange+"&dynamic=true";*/
        if(wsParamObj.apiversion==2.1 || wsParamObj.apiversion==2.2 || wsParamObj.apiversion==3.0){
            var serviceURL = constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_DRILLTHROUGH+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&hierarchyPath="+cleanURL(currentDeploymentEnv,wsParamObj.hierarchyPath)+"&status="+cleanURL(currentDeploymentEnv,wsParamObj.status)+"&dataType="+cleanURL(currentDeploymentEnv,wsParamObj.dataType)+"&aggregationType="+cleanURL(currentDeploymentEnv,wsParamObj.aggregationType)+"&dateRange="+wsParamObj.dateRange+"&dynamic=true";
        }
        else{
            var serviceURL = constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_DRILLTHROUGH+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&hierarchyPath="+cleanURL(currentDeploymentEnv,wsParamObj.hierarchyPath)+"&status="+cleanURL(currentDeploymentEnv,wsParamObj.status)+"&dataType="+cleanURL(currentDeploymentEnv,wsParamObj.dataType)+"&dateRange="+wsParamObj.dateRange+"&dynamic=true";
        }
        //var serviceURL = "http://9.3.68.40:11111/gps_operational_api/microsite/aggregations?clientName=Pepsico&hierarchyPath=H1%3AAMEA&aggregationType=COUNT&dataType=SLA&intervalType=monthly";//constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_METRICS+"clientName="+cleanURL(wsParamObj.clientName)+"&clientGeo="+cleanURL(wsParamObj.clientGeo)+"&clientCountry="+cleanURL(wsParamObj.clientCountry)+"&dataType="+cleanURL(wsParamObj.dataType)+"&dateType="+cleanURL(wsParamObj.dateType)+"&startDate="+wsParamObj.startDate;
        var config ={method: 'GET',url: serviceURL,headers: {'API_VERSION': wsParamObj.apiversion},data: {}};
        console.log("serviceURL getDrillThroughMetricData :" + serviceURL);
        return  http(config);
    }

    this.getApproverDrillThroughMetricData=function(wsParamObj,currentDeploymentEnv){
        var serviceURL = constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_APPROVER_DRILLTHROUGH+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&hierarchyPath="+cleanURL(currentDeploymentEnv,wsParamObj.hierarchyPath)+"&status="+cleanURL(currentDeploymentEnv,wsParamObj.status)+"&dataType="+cleanURL(currentDeploymentEnv,wsParamObj.dataType)+"&dateRange="+wsParamObj.dateRange+"&dynamic=true";
        //var serviceURL = "http://9.3.68.40:11111/gps_operational_api/microsite/aggregations?clientName=Pepsico&hierarchyPath=H1%3AAMEA&aggregationType=COUNT&dataType=SLA&intervalType=monthly";//constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_METRICS+"clientName="+cleanURL(wsParamObj.clientName)+"&clientGeo="+cleanURL(wsParamObj.clientGeo)+"&clientCountry="+cleanURL(wsParamObj.clientCountry)+"&dataType="+cleanURL(wsParamObj.dataType)+"&dateType="+cleanURL(wsParamObj.dateType)+"&startDate="+wsParamObj.startDate;
        var config ={method: 'GET',url: serviceURL,headers: {'API_VERSION': wsParamObj.apiversion},data: {}};
        console.log("serviceURL getDrillThroughMetricData :" + serviceURL);
        return  http(config);
    }

    this.getTopTenMetricData=function(wsParamObj,currentDeploymentEnv){
        var serviceURL = constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_TOP_METRICS_DATA+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&dynamic=true";
        var config ={method: 'GET',url: serviceURL,headers: {'API_VERSION': wsParamObj.apiversion},data: {}};
        console.log("serviceURL getAggregationsMetricData :" + serviceURL);
        return  http(config);
    }

    this.getCommentsData=function(wsParamObj,currentDeploymentEnv){
        var serviceURL = constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_COMMENTS+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&factKey="+wsParamObj.slaFactKey+"&dynamic="+wsParamObj.isCommentPosted;
        var config ={method: 'GET',url: serviceURL,headers: {'API_VERSION': wsParamObj.apiversion},data: {}};
        console.log("serviceURL getCommentsData :" + serviceURL);
        return  http(config);
    }

    this.getCommentsPredictiveData=function(wsParamObj,currentDeploymentEnv){
        //var serviceURL = "http://9.3.68.40:11111/gps_operational_api/microsite/commentGraphPredictive?clientName=Pepsico&factKey=168492&predictivePeriod="+6+"&regressionType=LINEAR&dynamic=true";
        var serviceURL = constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_PREDICTIVE+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&factKey="+wsParamObj.slaFactKey+"&predictivePeriod="+wsParamObj.predictivePeriod+"&regressionType=LINEAR&dynamic=true";
        var config ={method: 'GET',url: serviceURL,headers: {'API_VERSION': wsParamObj.apiversion},data: {}};
        console.log("serviceURL getCommentsData :" + serviceURL);
        return  http(config);
    }

    this.getConfigData=function(wsParamObj,currentDeploymentEnv){
        //console.log(wsParamObj);
        ///constructURI(currentDeploymentEnv)
        //9.3.68.40:11112/gps_operational_api/microsite/config?clientName=Manpower&dynamic=true
        ///"http://9.3.68.40:11112/gps_operational_api"+currentDeploymentEnv.DBD_EXTRAPARAM_CONFIG+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&dynamic=true";

        var serviceURL =constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_CONFIG+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&dynamic=true";//constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_CONFIG+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&dynamic=true";
        var config ={method: 'GET',url: serviceURL,headers: {'API_VERSION': "2.0"},data: {}};
        /*var serviceURL ="http://9.3.68.40:11112/gps_operational_api"+currentDeploymentEnv.DBD_EXTRAPARAM_CONFIG+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&dynamic=true";
         var config ={method: 'GET',url: serviceURL,headers: {'API_VERSION': "2.0","X_AUTH_TOKEN":"Td9jvC77jEWcpLMdkscXlGbSNCSjQlFU"},data: {}};*/
        console.log("serviceURL getCommentsData :" + serviceURL);
        return  http(config);
    }

    this.postComment=function(wsParamObj,currentDeploymentEnv,commentObj){
        var serviceURL = null;
        var config =null;
        if(wsParamObj.apiversion=="2.0" || wsParamObj.apiversion=="2.1" || wsParamObj.apiversion=="3.0"){
            if(wsParamObj.isLiferay){
                serviceURL=constructPostCommentURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_ADD_COMMENT+"slaFactKey="+commentObj.factkey+"&content="+cleanComment(currentDeploymentEnv,commentObj.commenttxt)+"&clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&action=POST";
                config ={method: 'GET',url: serviceURL,headers: {'API_VERSION': wsParamObj.apiversion}};
            }else if(wsParamObj.isLoginServlet){
                serviceURL=constructPostCommentURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_ADD_COMMENT;
                config ={method: 'POST',url: serviceURL,headers: {'X_AUTH_TOKEN': commentObj.commentAPITokenKey,'Content-Type':"application/json",'API_VERSION': wsParamObj.apiversion},data:{"content": cleanComment(currentDeploymentEnv,commentObj.commenttxt), "slaFactKey": commentObj.factkey,"userName":commentObj.userName,"clientName":cleanURL(currentDeploymentEnv,wsParamObj.clientName)}};
            }else{
                serviceURL=constructPostCommentURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_ADD_COMMENT;
                config ={method: 'POST',url: serviceURL,headers: {'X_AUTH_TOKEN': commentObj.commentAPITokenKey,'Content-Type':"application/json",'API_VERSION': wsParamObj.apiversion},data:{"content": cleanComment(currentDeploymentEnv,commentObj.commenttxt), "slaFactKey": commentObj.factkey,"clientName":cleanURL(currentDeploymentEnv,wsParamObj.clientName),"userName":commentObj.userName}};
            }
            return http(config);
        }else{
            if(wsParamObj.isLiferay){
                serviceURL=constructPostCommentURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_ADD_COMMENT+"slaFactKey="+commentObj.factkey+"&content="+cleanComment(currentDeploymentEnv,commentObj.commenttxt)+"&action=POST";
                config ={method: 'GET',url: serviceURL,headers: {'API_VERSION': wsParamObj.apiversion}};
            }else if(wsParamObj.isLoginServlet){
                serviceURL=constructPostCommentURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_ADD_COMMENT;
                config ={method: 'POST',url: serviceURL,headers: {'X_AUTH_TOKEN': commentObj.commentAPITokenKey,'Content-Type':"application/json",'API_VERSION': wsParamObj.apiversion},data:{"content": cleanComment(currentDeploymentEnv,commentObj.commenttxt), "slaFactKey": commentObj.factkey,"userName":commentObj.userName}};
            }else{
                serviceURL=constructPostCommentURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_ADD_COMMENT;
                config ={method: 'POST',url: serviceURL,headers: {'X_AUTH_TOKEN': commentObj.commentAPITokenKey,'Content-Type':"application/json",'API_VERSION': wsParamObj.apiversion},data:{"content": cleanComment(currentDeploymentEnv,commentObj.commenttxt), "slaFactKey": commentObj.factkey,"userName":commentObj.userName}};
            }
            console.log("serviceURL getCommentsData :" + serviceURL);
            console.log(config);
            return http(config);
        }

    }


    this.postApproverData=function(wsParamObj,currentDeploymentEnv,approverObj){
        var serviceURL = null;
        var config =null;
        if(wsParamObj.apiversion=="2.1" || wsParamObj.apiversion=="3.0"){
            if(wsParamObj.isLiferay){
                serviceURL=constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_ADD_APPROVER+"&approverMetricData=["+approverObj.approverMetricData+"]&clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&userName="+approverObj.userName;
                config ={method: 'GET',url: serviceURL,headers: {'API_VERSION': wsParamObj.apiversion}};
            }else if(wsParamObj.isLoginServlet){
                serviceURL=constructPostCommentURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_ADD_APPROVER;
                config ={method: 'POST',url: serviceURL,headers: {'X_AUTH_TOKEN': wsParamObj.apiKey,'Content-Type':"application/json",'API_VERSION': wsParamObj.apiversion},data:{"approverMetricData": approverObj.approverMetricData,"clientName":cleanURL(currentDeploymentEnv,wsParamObj.clientName),"userName":approverObj.userName}};
            }else{
                serviceURL=constructPostCommentURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_ADD_APPROVER;
                config ={method: 'POST',url: serviceURL,headers: {'X_AUTH_TOKEN': wsParamObj.apiKey,'Content-Type':"application/json",'API_VERSION': wsParamObj.apiversion},data:{"approverMetricData": approverObj.approverMetricData,"clientName":cleanURL(currentDeploymentEnv,wsParamObj.clientName),"userName":approverObj.userName}};
            }
        }
        console.log(serviceURL)
        console.log(config);
        return http(config);

    }

    this.getIntervalData = function(wsParamObj,currentDeploymentEnv)
    {
        ///console.log(wsParamObj);
        var serviceURL = constructURI(currentDeploymentEnv)+currentDeploymentEnv.DBD_EXTRAPARAM_INTERVAL+"clientName="+cleanURL(currentDeploymentEnv,wsParamObj.clientName)+"&dataType="+cleanURL(currentDeploymentEnv,wsParamObj.dataType);
        var config ={method: 'GET',url: serviceURL,headers: {'API_VERSION': wsParamObj.apiversion},data: {}};
        //console.log("serviceURL :" + serviceURL);
        return  http(config);

    }



}]);
