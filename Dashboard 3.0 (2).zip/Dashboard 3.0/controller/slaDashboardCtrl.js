/**
 * Created by karan_sonawane on 8/26/2016.
 */

location_macro.controller('slaDashboardCtrl', function ($scope, $rootScope, $location, portalservice, utilityService, $route, dashboardDataProcessFactory,$timeout,FlickityService) {
// usSpinnerService removed from above

    $scope.currentClientCofig = $route.current.$$route.config;
    $scope.wsTempParamObj = {
        clientName: $route.current.params.clientName,///$scope.currentClientCofig.name,
        clientGeo: $scope.currentClientCofig.geo,
        clientCountry: $scope.selectedDefaultCountry,
        dataType: DASH_DATA_TYPE_LBL,
        dateType: DASH_MONTHLY_LBL,
        startDate: 0,
        hierarchyPath: $scope.currentClientCofig.hierarchyPath,
        aggregationType: $scope.currentClientCofig.aggregationType,
        status: "",
        dateRange: "",
        slaFactKey: "",
        isCommentPosted: false,
        predictivePeriod: 0,
        isLiferay: $scope.currentClientCofig.isLiferay,
        isLoginServlet: $scope.currentClientCofig.isLoginServlet,
        apiversion: $scope.currentClientCofig.apiversion,
        updatedStatus: "",
        apiKey: $scope.currentClientCofig.commentAPITokenKey,
        avaliableGraphs:[0,0,0,0],
        defaultGraph:"",
        breakDownFilter:"A"
    }
    $scope.showDoughnut=false;
    $scope.userName="";
    $scope.treemapDataArr=[];
    if ($route.current.params.value != undefined) {
        $scope.selectedDefaultCountry = $route.current.params.value;
    } else {
        $scope.selectedDefaultCountry = $route.current.$$route.config.defaultCountry;
    }
    if ($route.current.params.userName != undefined) {
        $scope.userName = $route.current.params.userName;
    } else {
        $scope.userName = "admin@ibm.com";//fallback
    }
    /*usSpinnerService.spin('spinner-1');*/
    var barChartObj=null;
    var barChartObjLastMonths=null;
    var lineCommentObj=null;
    var lineCommentObjLast=null;
    var doughnutChartObj=null;
    var doughnutChartObjR=null;
    var doughnutChartObjG=null;
    var doughnutChartObjY=null;
    var isMLLoaded=false;
    $scope.totalOfDoughnutChart=0;
    $scope.isFirstSixMonths={first:false,commentsFirst:true};
    $scope.isPage2Visible=false;
    $scope.isCommentsVisible=false;
    $scope.isCardViewVisible=false;
    $scope.navHeaderTwo= $scope.currentClientCofig.drillDownHierarchyLabel;
    $scope.menuJSON={};
    $scope.btnLabelbar={firstHalf:"",secondHalf:""};
    $scope.commentBtnLabelLine={firstHalf:"",secondHalf:""};
    $scope.isLineChart=false;
    $scope.chartType="bar";
    $scope.donughtChart="doughnut";
    $scope.drillDownHierarchyArr = [];
    $scope.selectedDrillDownOption = {};
    $scope.maxDrillDownDepth=0;
    $scope.selectedMetricRecord = {};
    $scope.commentsChartButtonVisible=true;
    //graph var
    $scope.graphMonthArr = [];
    $scope.graphSLALabelArr = [];
    $scope.aggregatedGraphAllRecords={};
    $scope.graphCurrentValueArr = {firstHalf:[],secondHalf:[]};
    $scope.graphTargetValueArr = {firstHalf:[],secondHalf:[]};
    $scope.graphMinValueArr = {firstHalf:[],secondHalf:[]};
    $scope.portalAllTemp = [];
    $scope.drillDownLabelArr=[];
    $scope.aggregationsBarGraphData=[];
    $scope.selectedAggregationRecord = {};
    $scope.previousAggregationRecord = {};
    $scope.aggregationsDateArr=["May 2016"];
    $scope.aggregationsSelectedDate="";
    $scope.portalMonthSelectedIndex=0;
    $scope.aggregationsMetricMasterArr = [];
    $scope.portalAllMetricGroupRecords = [];
    $scope.portalLastTwelveMetricGroupRecords = [];
    $scope.selectedChartPointIndex = 0;
    $scope.isAggregationButtonVisible=true;
    $scope.selectedTheme="theme1";
    //comments
    $scope.selectedSLACommentArr = [];
    $scope.isCommentAdded = false;
    $scope.commentArea = {comment:""};
    $scope.postCommentObj = {};
    $scope.isViewCommentsVisible = false;
    var commentsGraphClickedIndex=2;
    $scope.isWeightedAverageOn = 0;
    $scope.weightedAverageOptionArr=["Count","Weighted"];
    $scope.selectedAggregationsType=$scope.weightedAverageOptionArr[0];
    $scope.weightedAverageOptionIndex=0;
    //metric-type
    $scope.metricTypeSelectedIndex = 0;
    $scope.menuDrillDown={
        "Hierarchy":[]
    };
    $scope.isDonutValueSet=false;
    $scope.isDonutValueGSet=false;
    $scope.hierarchyCommentList=[];
    $scope.aggregationsProcessArr=[];
    $scope.menuJSON={
        "Hierarchy":[
            {"name":"h1","data":[],"shortName":[]}, {"name":"h2","data":[],"shortName":[]}, {"name":"h3","data":[],"shortName":[]},
            {"name":"h4","data":[],"shortName":[]},{"name":"h5","data":[],"shortName":[]},{"name":"h6","data":[],"shortName":[]},{"name":"h7","data":[],"shortName":[]},
            {"name":"h8","data":[],"shortName":[]},{"name":"h9","data":[],"shortName":[]}
        ]
    };
    $scope.level="H0";
    var chartColorPalette={
        "theme1" :
        {
            "page1" :
            {
                min:"#D9182D",target:"#008A52",current:"#FFCF01",xGridLine:"rgba(38,38,47,.3)",yGridLine:"rgba(38,38,47,.3)",fontColor:"#26262F"
            }
            ,
            "page3" :
            {
                min:"#D9182D",target:"#008A52",current:"#262626",xGridLine:"rgba(38,38,47,.3)",yGridLine:"rgba(38,38,47,.3)",fontColor:"#26262F"
            }
        },
        "theme2" :
        {
            "page1" :
            {
                min:"#D9182D",target:"#008A52",current:"#FFCF01",xGridLine:"rgba(255,255,255,.3)",yGridLine:"rgba(255,255,255,.3)",fontColor:"rgba(255,255,255,.6)"
            }
            ,
            "page3" :
            {
                min:"#D9182D",target:"#008A52",current:"#262626",xGridLine:"rgba(255,255,255,.3)",yGridLine:"rgba(255,255,255,.3)",fontColor:"rgba(255,255,255,.6)"
            }
        }
    };
    /*var currentChartTheme=chartColorPalette.theme1;*/
    /*Get Barchart Object from directive*/
    $scope.getChartObjBar = function (obj) {
        barChartObj = obj.chart;
    };
    $scope.getChartObjBarLastMonth = function (obj) {
        barChartObjLastMonths = obj.chart;
    };
    $scope.getChartObjDoughnut = function (obj) {
        doughnutChartObj = obj.chart;
    };
    var updateChartThemeValues=function(theme){
        currentChartTheme=theme;
        $scope.doughnutChartData.datasets[0].backgroundColor = [currentChartTheme.page1.min, currentChartTheme.page1.target, currentChartTheme.page1.current];
        $scope.doughnutChartData.datasets[0].hoverBackgroundColor = [currentChartTheme.page1.min, currentChartTheme.page1.target, currentChartTheme.page1.current];
        if(doughnutChartObj){
            doughnutChartObj.update();
        }
        $scope.barChartData.datasets[0].backgroundColor=$scope.barChartData.datasets[0].borderColor=currentChartTheme.page1.target;
        $scope.barChartData.datasets[1].backgroundColor=$scope.barChartData.datasets[1].borderColor=currentChartTheme.page1.current;
        $scope.barChartData.datasets[2].backgroundColor=$scope.barChartData.datasets[2].borderColor=currentChartTheme.page1.min;
        $scope.barChartOption.scales.yAxes[0].gridLines.color=currentChartTheme.page1.xGridLine;
        $scope.barChartOption.scales.yAxes[0].ticks.fontColor=currentChartTheme.page1.fontColor;
        $scope.barChartOption.scales.xAxes[0].ticks.fontColor=currentChartTheme.page1.fontColor;
        $scope.lineChartCommentOption.scales.yAxes[0].gridLines.color=currentChartTheme.page3.xGridLine;
        $scope.lineChartCommentOption.scales.yAxes[0].ticks.fontColor=currentChartTheme.page3.fontColor;
        $scope.lineChartCommentOption.scales.xAxes[0].ticks.fontColor=currentChartTheme.page3.fontColor;
        $scope.barChartDataLastMonth.datasets[0].backgroundColor=$scope.barChartDataLastMonth.datasets[0].borderColor=currentChartTheme.page1.target;
        $scope.barChartDataLastMonth.datasets[1].backgroundColor=$scope.barChartDataLastMonth.datasets[1].borderColor=currentChartTheme.page1.current;
        $scope.barChartDataLastMonth.datasets[2].backgroundColor=$scope.barChartDataLastMonth.datasets[2].borderColor=currentChartTheme.page1.min;

        $scope.lineChartCommentData.datasets[0].pointHoverBackgroundColor=$scope.lineChartCommentData.datasets[0].borderColor=currentChartTheme.page3.target;
        $scope.lineChartCommentData.datasets[1].pointHoverBackgroundColor=$scope.lineChartCommentData.datasets[1].borderColor=currentChartTheme.page3.min;
        $scope.lineChartCommentData.datasets[2].pointHoverBackgroundColor=$scope.lineChartCommentData.datasets[2].borderColor=currentChartTheme.page3.current;
        $scope.lineChartCommentDataLast.datasets[0].pointHoverBackgroundColor=$scope.lineChartCommentDataLast.datasets[0].borderColor=currentChartTheme.page3.target;
        $scope.lineChartCommentDataLast.datasets[1].pointHoverBackgroundColor=$scope.lineChartCommentDataLast.datasets[1].borderColor=currentChartTheme.page3.min;
        $scope.lineChartCommentDataLast.datasets[2].pointHoverBackgroundColor=$scope.lineChartCommentDataLast.datasets[2].borderColor=currentChartTheme.page3.current;
        if(barChartObj){
            barChartObj.config.options.scales.yAxes[0].gridLines.color=barChartObjLastMonths.config.options.scales.yAxes[0].gridLines.color=currentChartTheme.page1.xGridLine;
            barChartObj.config.options.scales.yAxes[0].ticks.fontColor=barChartObjLastMonths.config.options.scales.yAxes[0].ticks.fontColor=currentChartTheme.page1.fontColor;
            barChartObj.config.options.scales.xAxes[0].ticks.fontColor=barChartObjLastMonths.config.options.scales.xAxes[0].ticks.fontColor=currentChartTheme.page1.fontColor;
            lineCommentObj.config.options.scales.yAxes[0].gridLines.color=lineCommentObjLast.config.options.scales.yAxes[0].gridLines.color=currentChartTheme.page3.xGridLine;
            lineCommentObj.config.options.scales.yAxes[0].ticks.fontColor=lineCommentObjLast.config.options.scales.yAxes[0].ticks.fontColor=currentChartTheme.page3.fontColor;
            lineCommentObj.config.options.scales.xAxes[0].ticks.fontColor=lineCommentObjLast.config.options.scales.xAxes[0].ticks.fontColor=currentChartTheme.page3.fontColor;
            barChartObj.update();
            barChartObjLastMonths.update();
            lineCommentObj.update();
            lineCommentObjLast.update();
            console.log(barChartObj);
        }
    }

    /* 3d carousel activate*/
    $(document).ready(function(){
        $('.menu-carousel').carousel3d();
    });

    /*bar graph in the content area. Divided in 2 pieces 1) Jan - June 2) Jul Dec. Code starts here*/
    $scope.barChartOption={
        responsive: true,
        scales: {
            xAxes: [
                {
                    ticks: {
                        fontColor: "#26262F", // this here
                    },
                    gridLines: {
                        color: "rgba(38,38,47,.3)", // this here
                        display:false
                    },
                    barPercentage: 0.8
                }
            ],
            yAxes: [
                {
                    ticks: {
                        fontColor: "#26262F", // this here
                    },
                    gridLines: {
                        color: "rgba(38,38,47,.3)", // this here
                        display:true,
                        zeroLineColor: "rgba(255,255,255,.25)"
                    }
                }
            ]
        },
        elements: { line:{
            tension:0.2
        }
        },
        legend:{
            display:false,
            position:"bottom"
        },
        tooltips:{
            enabled: false,
            // mode:"label",

        },


    };
    // page1 line graph first
    Chart.defaults.global.animationEasing = 'easeInOutQuad';
    $scope.barChartData = {
        labels: ["Jan","Feb","Mar","Apr","May","June"],
        datasets: [{
            label: 'Actual',
            data: [55,30,50,35,35,35],
            borderWidth: 2,
            fill: false,
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 5,
            pointBackgroundColor: "white",
        }, {
            label: 'Target',
            data: [18,25,30,15,15,15],
            borderWidth: 2,
            fill: false,
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 5,
            pointBackgroundColor: "white",
        }, {
            label: 'Min',
            data: [15,18,13,12,11,19],
            borderWidth: 2,
            fill: false,
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 5,
            pointBackgroundColor: "white",
        }]
    };


    // page1 line graph second
    $scope.barChartDataLastMonth = {
        labels: ["July","Aug","Sep","Oct","Nov","Dec"],
        datasets: [{
            label: 'Actual',
            data: [55,30,50,35,35,35],
            fill: false,
            borderWidth: 2,
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 5,
            pointBackgroundColor: "white",
        }, {
            label: 'Target',
            data: [18,25,30,15,15,15],
            fill: false,
            borderWidth: 2,
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 5,
            pointBackgroundColor: "white",
        }, {
            label: 'Min',
            data: [15,18,13,12,11,19],
            fill: false,
            borderWidth: 2,
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 5,
            pointBackgroundColor: "white",
        }]
    };
    $scope.doughnutChartOption = {

        responsive: true,
        maintainAspectRatio: false,
        tooltips:{
            enabled: false,
        },

        legend: {
            display: false
        },
        title: {
            display: false,
            text: ''
        },
        animation: {
            onProgress:function(obj){
                if($scope.isDonutValueSet){
                    $('.donutVal').each(function () {
                        $(this).prop('Counter',0).animate({
                            Counter: $(this).text()
                        }, {
                            duration: 1000,
                            easing: 'swing',
                            step: function (now) {
                                $(this).text(Math.ceil(now));
                            }
                        });
                    });
                    $scope.isDonutValueSet=false;
                }
            },
            easing:"easeOutBounce",
            animateScale: true,
            animateRotate: true,


        },
        cutoutPercentage: 67
    };
    $scope.doughnutChartData = {
        datasets: [{
            data: [20,20,20],
            borderWidth: 0,
            backgroundColor: [],
            hoverBackgroundColor: [],
            label: 'Dataset 1'
        }],
        labels: [
            "Below Minimum: ",
            "Over Target: ",
            "Over Minimum: "
        ],

    };
    // comments line graph
    $scope.lineChartCommentData={
        labels: ["Jan","Feb","Mar","Apr","May","June"],
        datasets: [ {
            label: 'Target',
            data: [0,0,0,0,0,0],
            borderWidth: 2,
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 5,
            pointBackgroundColor: ["white"],
            fill: false
        }, {
            label: 'Min',
            data: [0,0,0,0,0,0],
            borderWidth: 2,
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 5,
            pointBackgroundColor: ["white"],
            fill: false
        },{
            label: 'Actual',
            borderDash: [3,3],
            data: [0,0,0,0,0,0],
            borderWidth: 2,
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 5,
            pointBackgroundColor: ["white"],
            fill: true
        }]
    };
    $scope.lineChartCommentDataLast={
        labels: ["July","Aug","Sep","Oct","Nov","Dec"],
        datasets:[ {
            label: 'Target',
            data: [0,0,0,0,0,0],
            borderWidth: 2,
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 5,
            pointBackgroundColor: ["white"],
            fill: false,
        }, {
            label: 'Min',
            data: [0,0,0,0,0,0],
            borderWidth: 2,
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 5,
            pointBackgroundColor: ["white"],
            fill: false,
        },{
            label: 'Actual',
            data: [0,0,0,0,0,0],
            borderWidth: 2,
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 5,
            pointBackgroundColor: ["white"],
            fill: true
        }]
    }
    $scope.lineChartCommentOption={
        responsive: true,
        scales: {
            xAxes: [
                {
                    ticks: {
                        fontColor: "#26262F", // this here
                    },
                    gridLines: {
                        color: "rgba(38,38,47,.3)", // this here
                        display:false
                    }
                }
            ],
            yAxes: [
                {
                    ticks: {
                        fontColor: "#26262F", // this here
                    },
                    gridLines: {
                        color: "rgba(38,38,47,.3)", // this here
                        display:true
                    }
                }
            ]
        },
        elements: { line:{
            tension:0.2
        }
        },
        legend:{
            display:false,
            position:"bottom"
        },
        tooltips:{
            enabled: false
        },

    };
    $scope.chartTypeComment="line";
    updateChartThemeValues(chartColorPalette.theme1);

    $scope.showDialog=false;
    $scope.listViewNumberOfRecords=6;
    function openMenuML() {
        classie.add(menuEl, 'menu--open');
    }
    function closeMenuML() {
        classie.remove(menuEl, 'menu--open');
    }
    function closeMenuMLDate() {
        classie.remove(dateMenuEL, 'menu--open');
    }
    var createShortNameBreadcrumb=function(isMenuClicked){
        var breadCrumbObj={str:$scope.currentClientCofig.drillDownHierarchyLabel,currentSelectedMenuItem:""};

        var counter=0;
        var currentSelectedMenuItem="";
        if(isMenuClicked){
            $('#ml-menu .menu__link.active').each(function() {
                var ind=$scope.menuJSON.Hierarchy[counter].data.indexOf($(this).text());
                breadCrumbObj.str=breadCrumbObj.str+" > "+ $scope.menuJSON.Hierarchy[counter].shortName[ind];
                breadCrumbObj.currentSelectedMenuItem=$(this).text();
                counter++;
            });
        }
        else{
            $('#ml-menu .menu__breadcrumbs a:gt(0)').each(function() {
                var ind=$scope.menuJSON.Hierarchy[counter].data.indexOf($(this).text());
                breadCrumbObj.str=breadCrumbObj.str+" > "+ $scope.menuJSON.Hierarchy[counter].shortName[ind];
            });
        }

        return breadCrumbObj;
    }
    $scope.showBreadcrumbData=function(ev,itemName,index,index2) {
        console.log($scope.menuDrillDown.Hierarchy);
        console.log($scope.menuJSON.Hierarchy[index].shortName[index2]);
        closeMenuML();
        console.log($(ev.target).siblings());
        $(ev.target).addClass('active').parent().siblings().children().removeClass('active');
        ev.preventDefault();
        var str="";
        var currentSelectedMenuItem="";
        var breadCrumbObj=createShortNameBreadcrumb(true);
        $('#ml-menu .menu__breadcrumbs a:last').text(breadCrumbObj.currentSelectedMenuItem);

        $scope.drillDownHierarchyArr[index+1] = {
            label: itemName,
            level: "H"+(index+1),
            id: (index+1)
        };

        if($scope.isPage2Visible || $scope.isCommentsVisible){
            FlickityService.select($scope.flickityId_main, 0);
            $scope.isPage2Visible=false;
            $scope.isCommentsVisible=false;
        }
        $scope.selectedDrillDownOption.hierarchy=$scope.drillDownHierarchyArr[index+1].level;
        $scope.selectedDrillDownOption.optionLabel=$scope.drillDownHierarchyArr[index+1].label;
        $scope.navHeaderTwo=breadCrumbObj.str;
        if(!$scope.$$phase) {
            $scope.$digest();
        }

        $scope.changeAggregationsDownOption(index+1);
    }
    $scope.changeAggregationsMonth=function(index) {
        $scope.portalMonthSelectedIndex=index;
        $scope.aggregationsSelectedDate=$scope.aggregationsDateArr[index];
        index=($scope.aggregationsDateArr.length-1)-index;
        $scope.totalOfDoughnutChart=$scope.aggregatedGraphAllRecords.target[index]+$scope.aggregatedGraphAllRecords.current[index]+$scope.aggregatedGraphAllRecords.min[index];
        $('.donutVal').text($scope.totalOfDoughnutChart);

        $scope.doughnutChartData.datasets[0].data[1]=$scope.selectedAggregationRecord.green=$scope.aggregatedGraphAllRecords.target[index];
        $scope.doughnutChartData.datasets[0].data[2]=$scope.selectedAggregationRecord.yellow=$scope.aggregatedGraphAllRecords.current[index];
        $scope.doughnutChartData.datasets[0].data[0]=$scope.selectedAggregationRecord.red=$scope.aggregatedGraphAllRecords.min[index];
        $('.donutValG').text($scope.selectedAggregationRecord.green);
        $('.donutValY').text($scope.selectedAggregationRecord.yellow);
        $('.donutValR').text($scope.selectedAggregationRecord.red);
        $scope.isDonutValueSet=true;
        $scope.isDonutValueGSet=true;
        $scope.doughnutChartBottomDataY.datasets[0].data[0]=$scope.selectedAggregationRecord.yellow;
        $scope.doughnutChartBottomDataY.datasets[0].data[1]=($scope.selectedAggregationRecord.green+$scope.selectedAggregationRecord.red);
        // doughnutChartObjY.update();
        $scope.doughnutChartBottomDataR.datasets[0].data[0]=$scope.selectedAggregationRecord.red;
        $scope.doughnutChartBottomDataR.datasets[0].data[1]=($scope.selectedAggregationRecord.yellow+$scope.selectedAggregationRecord.green);
        // doughnutChartObjR.update();
        $scope.doughnutChartBottomDataG.datasets[0].data[0]=$scope.selectedAggregationRecord.green;
        $scope.doughnutChartBottomDataG.datasets[0].data[1]=($scope.selectedAggregationRecord.yellow+$scope.selectedAggregationRecord.red);
        // doughnutChartObjG.update();
        $scope.selectedAggregationRecord.interval=$scope.aggregatedGraphAllRecords.interval[index];
        doughnutChartObj.update();
        if($scope.aggregatedGraphAllRecords.min[index-1]){
            $scope.previousAggregationRecord.green=$scope.aggregatedGraphAllRecords.target[index-1];
            $scope.previousAggregationRecord.yellow=$scope.aggregatedGraphAllRecords.current[index-1];
            $scope.previousAggregationRecord.red=$scope.aggregatedGraphAllRecords.min[index-1];
        }
        if($scope.isPage2Visible){
            $scope.aggregationsMetricMasterArr=[];
            $scope.wsTempParamObj.dateRange = $scope.selectedAggregationRecord.interval;
            $scope.getDrillThroughMetricData($scope.wsTempParamObj);
        }
        console.log($scope.processAggregationMasterGraphArr);
        dashboardDataProcessFactory.processBreakDownArr($scope.processAggregationMasterGraphArr,$scope);
        ///dashboardDataProcessFactory.processJSON($scope.processAggregationMasterGraphArr,$scope);
        // closeMenuMLDate();

    }

    $scope.calculateTheDoughnutPer=function(value){
        if(value!=null){
            return Math.abs(value/$scope.totalOfDoughnutChart*100).toFixed(2);
        }else{
            return "";
        }

    }

    //change the process for aggregation data
    $scope.portalProcessSelectedIndex=0;
    $scope.changeAggregationsProcess = function () {
        $scope.aggregationsMetricMasterArr = [];
        $scope.portalProcessSelectedIndex = this.$index;
        $scope.processValue = this.rec;
        if($scope.processValue.indexOf('All')!=-1){
            $scope.wsTempParamObj.breakDownFilter="A";
        }else{
            $scope.wsTempParamObj.breakDownFilter=$scope.processValue;
        }

        if($scope.isCardViewVisible){
            $scope.filterProcess($scope.processValue, $scope.portalStatusValue);
        }else{
            $scope.getAggregationsData($scope.wsTempParamObj);
            $scope.getFullHierarchy($scope.wsTempParamObj);
        }

    };

    $scope.getChartObjLineComment = function (obj,index) {
        lineCommentObj = obj.chart;
        var gradient = lineCommentObj.chart.ctx.createLinearGradient(0, 0, 0, 450);
        gradient.addColorStop(1, 'rgba(90,168,69, 0.0)');
        gradient.addColorStop(0.5, 'rgba(90,168,69, 0.0)');
        gradient.addColorStop(0.3, 'rgba(90,168,69, 0.0)');
        gradient.addColorStop(0, 'rgba(90,168,69, 0.0)');
        $scope.lineChartCommentData.datasets[2].backgroundColor= gradient;
        lineCommentObj.update();
    };
    $scope.getChartObjLineCommentLast = function (obj) {
        lineCommentObjLast = obj.chart;
        var gradient = lineCommentObjLast.chart.ctx.createLinearGradient(0, 0, 0, 450);
        gradient.addColorStop(1, 'rgba(90,168,69, 0.0)');
        gradient.addColorStop(0.5, 'rgba(90,168,69, 0.0)');
        gradient.addColorStop(0.3, 'rgba(90,168,69, 0.0)');
        gradient.addColorStop(0, 'rgba(90,168,69, 0.0)');
        $scope.lineChartCommentDataLast.datasets[2].backgroundColor= gradient;
        lineCommentObjLast.update();
        console.log(lineCommentObj);
    };

    $scope.navigateNextPage=function(){
        $scope.isPage2Visible=true;
        if($scope.aggregationsMetricMasterArr.length==0){
            $('.view-record').text("0 - 0" );
        }
        $scope.isCommentsVisible=false;
        FlickityService.select($scope.flickityId_main, 1);

    }
    $scope.navigateBack=function(){
        if($scope.isPage2Visible){
            FlickityService.select($scope.flickityId_main, 0);
            $scope.isPage2Visible=!$scope.isPage2Visible;
            console.log($scope.isCardViewVisible);

        }
        else if($scope.isCommentsVisible){
            FlickityService.select($scope.flickityId_main, 1);
            $scope.isCommentsVisible=false;
            $scope.isPage2Visible=true;
        }

    }
    $scope.navigateCommentPage=function(){
        FlickityService.select($scope.flickityId_main,2);
        $scope.isPage2Visible=false;
        $scope.isCommentsVisible=true;
    }
    /*Flickity Config Code starts here*/
    // We are defining our own ID so that we can reference it later
    $scope.flickityId = 'flickityId';
    $scope.flickityOptions = {
        cellSelector: '.demo__slide',
        prevNextButtons: false,
        friction: .4,
        selectedAttraction: .1,
        pageDots:false,
        accessibility: false,
        initialIndex: 1
    };
    $scope.flickityIdComments="commentsFlickitySlides";
    $scope.flickityOptionsComments = {
        cellSelector: '.demo__slide_comment',
        prevNextButtons: false,
        friction: .4,
        selectedAttraction: .1,
        pageDots:false,
        accessibility: false
    };
    $scope.flickityIdCommentsWrapper="flickityIdCommentsWrapper";
    $scope.flickityOptionsCommentsWrapper = {
        cellSelector: '.demo__slide_comment_wrapper',
        prevNextButtons: false,
        friction: .4,
        selectedAttraction: .1,
        pageDots:false,
        draggable: false,
        accessibility: false
    };
    //Flickity Main carousel for page wrapping
    $scope.flickityId_main = 'flickityId_main';
    $scope.flickityOptions_main = {
        cellSelector: '.demo__slide_main',
        prevNextButtons: false,
        /* friction: .4,
         selectedAttraction: .1,*/
        pageDots:false,
        draggable: false,
        accessibility: false
    };
    $scope.flickityIdCard='flickityIdCard';
    $scope.flickityOptionsCard = {
        cellSelector: '.demo__slide_card',
        prevNextButtons: false,
        pageDots:false,
        draggable: false,
        accessibility: false
    };
    // on flickity cell select add active class to custom buttons
    var settle = $rootScope.$on('Flickity:flickityId:select', function(event, data) {
        if(data.instance.cells[0].element.className.search("is-selected")>0){
            $scope.isFirstSixMonths.first=true;
        }
        else if(data.instance.cells[1].element.className.search("is-selected")>0){
            $scope.isFirstSixMonths.first=false;
        }
        if(!$scope.$$phase) {
            $scope.$digest();
        }
    });
    var settleComments = $rootScope.$on('Flickity:commentsFlickitySlides:select', function(event, data) {
        /* console.log(event);
         console.log(data);*/
        /*data.instance.bindDrag();*/
        if(data.instance.cells[0].element.className.search("is-selected")>0){
            $scope.isFirstSixMonths.commentsFirst=true;
        }
        else if(data.instance.cells[1].element.className.search("is-selected")>0){
            $scope.isFirstSixMonths.commentsFirst=false;
        }
        if(!$scope.$$phase) {
            $scope.$digest();
        }
    });
    // Go to the first slide when clicked
    $scope.showJanToJun = function() {
        // Go directly to the first cell
        FlickityService.select($scope.flickityId, 0);
    };
    $scope.showJulToDec = function() {
        // Go directly to the second cell
        FlickityService.select($scope.flickityId, 1);
    };
    $scope.showJanToJunComments = function() {
        // Go directly to the first cell
        FlickityService.select($scope.flickityIdComments, 0);
    };
    $scope.showJulToDecComments = function() {
        // Go directly to the second cell
        FlickityService.select($scope.flickityIdComments, 1);
    };
    var intializeViewRecordValue=function(type){
        $("."+type).scrollTop(0);

        if(type=='card-view'){
            if($scope.aggregationsMetricMasterArr.length>4){
                $('.view-record').text("1 - 4");
            }
            else if($scope.aggregationsMetricMasterArr.length==0){
                $('.view-record').text("0 - 0" );
            }
            else{
                $('.view-record').text("1 - " +$scope.aggregationsMetricMasterArr.length);
            }
        }
        else{
            if($scope.aggregationsMetricMasterArr.length>6){
                $('.view-record').text("1 - "+$scope.listViewNumberOfRecords);
            }
            else if($scope.aggregationsMetricMasterArr.length==0){
                $('.view-record').text("0 - 0" );
            }
            else{
                $('.view-record').text("1 - " +$scope.aggregationsMetricMasterArr.length);
            }
        }

    }

    $scope.showListView = function() {
        intializeViewRecordValue('list-view');
        $scope.isCardViewVisible=false;
        // Go directly to the first cell
        FlickityService.select($scope.flickityIdCard, 0);
    };
    $scope.showCardView = function() {
        intializeViewRecordValue('card-view');
        $scope.isCardViewVisible=true;
        // Go directly to the second cell
        FlickityService.select($scope.flickityIdCard, 1);
    };

    /*Multi level menu code starts here*/

    $scope.changeChartType=function(e){
        console.log(e.target.checked);
        if(e.target.checked){
            $scope.chartType='line';
        }
        else{
            $scope.chartType='bar';
        }


        if($scope.chartType=='bar'){
            $scope.barChartData.datasets[0].fill= false;
            $scope.isLineChart=false;
            $scope.barChartData.datasets[0].backgroundColor="#008A52";
            $scope.barChartDataLastMonth.datasets[0].fill= false;
            $scope.barChartDataLastMonth.datasets[0].backgroundColor="#008A52";
        }

        else{
            /* $scope.isLineChart=true;
             $scope.barChartData.datasets[0].fill= true;
             console.log(barChartObj);
             var gradient = barChartObj.chart.ctx.createLinearGradient(0, 0, 0, 450);
             gradient.addColorStop(1, 'rgba(90,168,69, 0.0)');
             gradient.addColorStop(0.5, 'rgba(90,168,69, 0.0)');
             gradient.addColorStop(0.3, 'rgba(90,168,69, 0.0)');
             gradient.addColorStop(0, 'rgba(90,168,69, 0.0)');
             $scope.barChartData.datasets[0].backgroundColor= gradient;
             $scope.barChartDataLastMonth.datasets[0].fill= true;
             var gradient2 = barChartObjLastMonths.chart.ctx.createLinearGradient(0, 0, 0, 450);
             gradient2.addColorStop(0, 'rgba(90,168,69, 0)');
             gradient2.addColorStop(0.3, 'rgba(90,168,69, 0.0)');
             gradient2.addColorStop(0.5, 'rgba(90,168,69, 0.0)');
             gradient2.addColorStop(0.75, 'rgba(90,168,69, 0.0)');
             gradient2.addColorStop(1, 'rgba(90,168,69, 0)');
             $scope.barChartDataLastMonth.datasets[0].backgroundColor= gradient2;*/

        }

    }
    $scope.changeCardListView=function(e){
        if(e.target.checked){
            $scope.showListView();
        }
        else{
            $scope.showCardView();

        }
    }
    /*WS Implementation*/
    //page load function on router
    $scope.loadAggregationsData = function () {
        $scope.getConfigData($scope.wsTempParamObj);
    }
    //load configuration
    $scope.getConfigData = function (wsParamObj) {
        // usSpinnerService.spin('spinner-1');
        var promise = portalservice.getConfigData(wsParamObj, $scope.currentClientCofig.deploymentEnv);
        console.log(promise);
        promise.success(function (response) {
            if (response.errorCode === 0) {
                //console.log(response);
                dashboardDataProcessFactory.processConfigData($scope, response.result)
                $scope.isAjaxComplete = true;
                $scope.portalWebSeviceErrorMsg = false;
                $scope.isServiceFailed = false;
                // usSpinnerService.stop('spinner-1');
            }
            else {
                $scope.portalWebSeviceErrorMsg = true;//response.errorMsg;
                // usSpinnerService.stop('spinner-1');
                $scope.showErrorModal(DASH_CLIENT_NOT_FOUND_ERR_MSG);
            }
        });
        promise.error(function (err) {
            // usSpinnerService.stop('spinner-1');
            $scope.isServiceFailed = true;
            $scope.showErrorModal(err);
        });
    }

    $scope.showErrorMessageDialog = function (message) {
        $scope.errorDialogText = message;
        //$("#errorModal").modal("show");
    }

    //get top ten metric data
    $scope.getTopTenMetricData = function (wsParamObj) {
        // usSpinnerService.spin('spinner-1');
        var promise = portalservice.getTopTenMetricData(wsParamObj, $scope.currentClientCofig.deploymentEnv);
        promise.success(function (response) {
            if (response.errorCode === 0) {
                dashboardDataProcessFactory.processTopTenMetricData($scope, response.result);
                $scope.isAjaxComplete = true;
                $scope.portalWebSeviceErrorMsg = false;
                $scope.isServiceFailed = false;
                // usSpinnerService.stop('spinner-1');
            }
            else {
                $scope.portalWebSeviceErrorMsg = true;//response.errorMsg;
                // usSpinnerService.stop('spinner-1');
                $scope.showErrorModal(response.errorMessage);
            }
        });
        promise.error(function (err) {
            // usSpinnerService.stop('spinner-1');
            $scope.isServiceFailed = true;
            $scope.showErrorModal(err);
        });
    }

    //init variables for WS call
    $scope.initAggregationData = function () {
        /*if (aggChartObj != null) {
         aggChartObj.clear();
         aggChartObj.destroy();

         }*/
        //Menu intialization only first time
        /* if(!isMLLoaded){
         setTimeout(function(){
         (function() {
         menuEl=null;
         mlmenu=null;
         dateMenu=null;
         dateMenuEL=null;
         menuEl = document.getElementById('ml-menu');
         mlmenu = new MLMenu(menuEl, {
         breadcrumbsCtrl : true, // show breadcrumbs
         initialBreadcrumb : $scope.currentClientCofig.drillDownHierarchyLabel, // initial breadcrumb text
         backCtrl : false, // show back button
         // itemsDelayInterval : 60, // delay between each menu item sliding animation
         /!*onItemClick: showBreadcrumbData*!/
         // callback: item that doesn´t have a submenu gets clicked - onItemClick([event], [inner HTML of the clicked item])
         });
         /!*console.log(mlmenu);*!/
         dateMenuEL = document.getElementById('date-menu');
         dateMenu = new MLMenu(dateMenuEL, {
         breadcrumbsCtrl : false, // show breadcrumbs
         initialBreadcrumb : "", // initial breadcrumb text
         backCtrl : false, // show back button
         });
         function openMenuMLDate() {
         classie.add(dateMenuEL, 'menu--open');
         }
         function closeMenuMLDate() {
         classie.remove(dateMenuEL, 'menu--open');
         }
         // mobile menu toggle
         var openMenuCtrl2 = document.querySelector('.action--openTwo');
         var closeMenuCtrl2 = document.querySelector('.action--closeTwo');
         openMenuCtrl2.addEventListener('click', openMenuMLDate);
         closeMenuCtrl2.addEventListener('click', closeMenuMLDate);

         function openMenuML() {
         classie.add(menuEl, 'menu--open');
         }
         function closeMenuML() {
         classie.remove(menuEl, 'menu--open');
         }
         // mobile menu toggle
         var openMenuCtrl = document.querySelector('.action--open');
         var closeMenuCtrl = document.querySelector('.action--close');
         openMenuCtrl.addEventListener('click', openMenuML);
         closeMenuCtrl.addEventListener('click', closeMenuML);
         $( "#ml-menu .menu__breadcrumbs a:eq(0)" ).on( "click", function() {

         $scope.navHeaderTwo=$scope.currentClientCofig.drillDownHierarchyLabel;
         $('.menu__item a').removeClass('active');
         for(var i=1;i<$scope.menuJSON.Hierarchy.length;i++){
         $scope.menuJSON.Hierarchy[i].data.length=0;
         $scope.menuJSON.Hierarchy[i].data=[];
         $scope.menuJSON.Hierarchy[i].shortName=[];
         }
         if(!$scope.$$phase) {
         $scope.$digest();
         }
         if($scope.isPage2Visible){
         FlickityService.select($scope.flickityId_main, 0);
         $scope.isPage2Visible=false;
         }
         $scope.drillDownOptionSelectedIndex=0;
         console.log();
         $scope.drillDownHierarchyArr.splice(1, $scope.drillDownHierarchyArr.length - 1);
         $scope.wsTempParamObj.hierarchyPath = $scope.drillDownHierarchyArr[0].level + ":" + $scope.drillDownHierarchyArr[0].label;
         $scope.getAggregationsData($scope.wsTempParamObj);

         closeMenuML()
         });
         $( "#ml-menu .menu__breadcrumbs" ).on( "click", function(e) {
         console.log("breadcrumb clicked")

         var index_breadCrumb=[].indexOf.call(e.target.parentNode.children, e.target);
         console.log(index_breadCrumb);
         if(index_breadCrumb!=0){
         for(var i=index_breadCrumb;i<$scope.menuJSON.Hierarchy.length;i++){
         $scope.menuJSON.Hierarchy[i].data.length=0;
         $scope.menuJSON.Hierarchy[i].data=[];
         $scope.menuJSON.Hierarchy[i].shortName=[];
         }
         var breadCrumbObj=createShortNameBreadcrumb(false);
         /!*var str=$scope.currentClientCofig.drillDownHierarchyLabel;
         $('#ml-menu .menu__breadcrumbs a:gt(0)').each(function() {
         str=str+" / "+ $(this).text();
         });*!/
         if($scope.isPage2Visible){
         FlickityService.select($scope.flickityId_main, 0);
         $scope.isPage2Visible=false;
         }
         $scope.navHeaderTwo=breadCrumbObj.str;
         if(!$scope.$$phase) {
         $scope.$digest();
         }
         $scope.drillDownHierarchyArr.splice(index_breadCrumb+1, $scope.drillDownHierarchyArr.length - 1);
         $scope.changeAggregationsDownOption(index_breadCrumb)
         }

         });
         })();

         }, 0);
         isMLLoaded=true;
         }*/

        $scope.aggregationsGraphData = [];
        $scope.aggregationsMonthsArr = [];
        $scope.aggregationsGreenValArr = [];
        $scope.aggregationsRedValArr = [];
        $scope.aggregationsYellowValArr = [];
        ///$scope.aggregationsChartData = {};
        $scope.aggregationsChartObj = [];
        $scope.aggregationsMasterArr = [];
        $scope.selectedAggregationRecord = {yellow:0,red:0,green:0,interval:""};
        $scope.previousAggregationRecord  = {yellow:0,red:0,green:0,interval:""};
        $scope.selectedAggregationAppRecord = {};
        $scope.portalMonthSelectedIndex = 0;
        $scope.aggregationsGraphData = [];
        ///$scope.aggregationsChartData = {};
        $scope.selectedAggregationRecord = {};
        $scope.drillDownOptionSelectedIndex = -1;

    }
    //Pull down menu
    var pullMenuEl = document.querySelector('.pull-side-menu')
    var handleEls = document.querySelectorAll('.nav-side, .close-handle')
    var isOpen = true
    var boundry = new Impulse.Boundry({ top: 0, bottom: 0, left: 0, right: 1500 })

    var pullDownMenu = new Impulse(pullMenuEl)
        .style('translateX', function(x, y) { return x + 'px' })

    var drag = pullDownMenu.drag({ handle: handleEls, boundary: boundry, direction: 'horizontal' })

    function end() {
        if(this.moved()) {
            isOpen = pullDownMenu.direction('right')
        } else {
            isOpen = !isOpen
            if(isOpen) {
                pullDownMenu.velocity(0,2000)
            }
        }

        if(isOpen) {
            $('.pull-side-menu').css('display','block')
            pullMenuEl.classList.add('open')
            pullDownMenu.accelerate({ acceleration: 1500, bounceAcceleration: 4000, bounce: this.moved() })
                .to(boundry.right, 0).start()
                .then(function() {
                })
        } else {
            $('.pull-side-menu').css('display','block')
            pullMenuEl.classList.remove('open')
            pullDownMenu.spring({ tension: 100, damping: 15 })
                .to(boundry.left, 0).start()
        }
    }

    drag.on('end', end)
    pullMenuEl.classList.add('open')
    pullDownMenu.accelerate({ acceleration: 1500, bounceAcceleration:0})
        .to(boundry.right, 0).start()

    /*Pull down menu  changes ends here*/

    //aggregations data for drill-down graph
    $scope.getAggregationsData = function (wsParamObj) {
        // usSpinnerService.spin('spinner-1');
        var promise = portalservice.getAggregationsData(wsParamObj, $scope.currentClientCofig.deploymentEnv);
        promise.success(function (response) {
            if (response.errorCode === 0) {
                $scope.aggregationsGraphData = response.result;
                if ($scope.aggregationsGraphData != null || $scope.aggregationsGraphData != undefined) {
                    //$scope.processAggregationsData($scope.aggregationsGraphData);
                    dashboardDataProcessFactory.processAggregationsData($scope, $scope.aggregationsGraphData);
                    doughnutChartObj.update();
                    // doughnutChartObjY.update();
                    // doughnutChartObjR.update();
                    // doughnutChartObjG.update();
                    //Assign Barchart values
                    $scope.barChartData.datasets[0].data=$scope.graphTargetValueArr.firstHalf;
                    $scope.barChartData.datasets[1].data=$scope.graphCurrentValueArr.firstHalf;
                    $scope.barChartData.datasets[2].data=$scope.graphMinValueArr.firstHalf;

                    /* $scope.barChartDataLastMonth.datasets[0].data=$scope.graphTargetValueArr.secondHalf;
                     $scope.barChartDataLastMonth.datasets[1].data=$scope.graphCurrentValueArr.secondHalf;
                     $scope.barChartDataLastMonth.datasets[2].data=$scope.graphMinValueArr.secondHalf;*/

                    barChartObj.update();
                    //barChartObjLastMonths.update();
                }

                $scope.isAjaxComplete = true;
                $scope.portalWebSeviceErrorMsg = false;
                $scope.isServiceFailed = false;
                // usSpinnerService.stop('spinner-1');
            }
            else {
                $scope.portalWebSeviceErrorMsg = true;//response.errorMsg;
                // usSpinnerService.stop('spinner-1');
                $scope.showErrorModal(response.errorMessage);
            }
        });
        promise.error(function (err) {
            // usSpinnerService.stop('spinner-1');
            $scope.isServiceFailed = true;
            $scope.showErrorModal(err);
        });
    }

    $scope.getHierarchyCommentListData = function (wsParamObj) {
        // usSpinnerService.spin('spinner-1');
        var promise = portalservice.getHierarchyCommentListData(wsParamObj, $scope.currentClientCofig.deploymentEnv);
        promise.success(function (response) {
            if (response.errorCode === 0) {
                $scope.hierarchyCommentList = response.result.hierarchyCommentList;
                console.log($scope.hierarchyCommentList);

                $scope.isAjaxComplete = true;
                $scope.portalWebSeviceErrorMsg = false;
                $scope.isServiceFailed = false;
                // usSpinnerService.stop('spinner-1');
            }
            else {
                $scope.portalWebSeviceErrorMsg = true;//response.errorMsg;
                // usSpinnerService.stop('spinner-1');
                $scope.showErrorModal(response.errorMessage);
            }
        });
        promise.error(function (err) {
            // usSpinnerService.stop('spinner-1');
            $scope.isServiceFailed = true;
            $scope.showErrorModal(err);
        });
    }


    $scope.getDrillDownPath = function (arr) {
        console.log(arr);
        var str = "";
        for (var i = 1; i < arr.length; i++) {
            str += arr[i].level + ":" + arr[i].label + "|";
        }
        return str;
    }
    /*//change the drill-down for aggregation data
     $scope.changeAggregationsDownOption = function (index) {

     $scope.aggregationsMetricMasterArr = [];
     /!*$scope.isCardViewVisible = false;*!/
     $scope.initAggregationData();
     $scope.drillDownOptionSelectedIndex = index;
     $scope.optionLabel = $scope.selectedDrillDownOption.optionLabel;
     //  $scope.wsTempParamObj.startDate = $scope.portalMonthSelectedTimeStamp;

     //$scope.selectedDrillDownOption[1];

     if ($scope.wsTempParamObj.apiversion == "2.0" || $scope.wsTempParamObj.apiversion == "2.1") {
     if ($scope.getDrillDownPath($scope.drillDownHierarchyArr) != "") {
     $scope.wsTempParamObj.hierarchyPath = $scope.getDrillDownPath($scope.drillDownHierarchyArr);
     $scope.wsTempParamObj.hierarchyPath=$scope.wsTempParamObj.hierarchyPath.slice(0,-1);
     } else {
     $scope.wsTempParamObj.hierarchyPath = $scope.selectedDrillDownOption.hierarchy + ":" + $scope.selectedDrillDownOption.optionLabel;
     }
     } else {
     $scope.wsTempParamObj.hierarchyPath = $scope.selectedDrillDownOption.hierarchy + ":" + $scope.selectedDrillDownOption.optionLabel;
     }

     $scope.getAggregationsData($scope.wsTempParamObj);

     };*/
    //change the drill-down for aggregation data
    $scope.changeAggregationsDownOption = function () {
        $scope.aggregationsMetricMasterArr = [];
        $scope.isCardViewVisible = false;
        $scope.initAggregationData();
        $scope.drillDownOptionSelectedIndex = this.$index;
        $scope.selectedDrillDownOption = this.rec;
        $scope.optionLabel = $scope.selectedDrillDownOption.shortname;
        $scope.wsTempParamObj.startDate = $scope.portalMonthSelectedTimeStamp;

        //$scope.selectedDrillDownOption[1];

        if ($scope.wsTempParamObj.apiversion == "2.0" || $scope.wsTempParamObj.apiversion == "2.1" ||$scope.wsTempParamObj.apiversion == "2.2" || $scope.wsTempParamObj.apiversion == "3.0") {
            if ($scope.getDrillDownPath($scope.drillDownHierarchyArr) != "") {
                $scope.wsTempParamObj.hierarchyPath = $scope.getDrillDownPath($scope.drillDownHierarchyArr) + $scope.selectedDrillDownOption.hierarchy + ":" + $scope.selectedDrillDownOption.optionLabel
            } else {
                $scope.wsTempParamObj.hierarchyPath = $scope.selectedDrillDownOption.hierarchy + ":" + $scope.selectedDrillDownOption.optionLabel;
            }
        } else {
            $scope.wsTempParamObj.hierarchyPath = $scope.selectedDrillDownOption.hierarchy + ":" + $scope.selectedDrillDownOption.optionLabel;
        }

        $scope.getAggregationsData($scope.wsTempParamObj);
        $scope.getFullHierarchy($scope.wsTempParamObj);

    };
    // display the trends status
    $scope.displayTrendStatus = function (str) {
        switch (String(str).trim().toUpperCase()) {
            case "U":
                return {'ico-trend-up': true};
                break;
            case "D":
                return {'ico-trend-down': true};
                break;
            case "S":
                return {'ico-trend-right': true};
                break;
            default:
                return {'ico-trend-right': true};

        }
    };
    var clearDrillDownHierarchy=function(index){
        for(var i=index;i<$scope.menuJSON.Hierarchy.length;i++){
            $scope.menuJSON.Hierarchy[i].data.length=0;
            $scope.menuJSON.Hierarchy[i].data=[];
            $scope.menuJSON.Hierarchy[i].shortName=[];
        }
    }
    //calculate the trends arrow direction
    $scope.calculateTrends = function (selectedMonthRecord, previousMonthRecord) {
        return utilityService.calculateTrends(selectedMonthRecord, previousMonthRecord);
    }
    var backMenuFunction=function(mlmenu2){
        $('.menu__item a').removeClass('active');
        mlmenu2._menuIn(mlmenu2.menus[0],undefined);
        $('.menu__breadcrumbs a').not(':first').remove();
    }
    //click on metric type
    $scope.onClickMetricType = function (rec, index) {
        $scope.isCardViewVisible = false;
        $scope.drillDownHierarchyArr = [];
        $scope.aggregationsProcessArr = [];
        $scope.drillDownHierarchyArr[0] = {
            label: $scope.currentClientCofig.drillDownHierarchyLabel,
            level: "H0",
            id: 0
        };
        $scope.wsTempParamObj.dataType = rec.metricType;
        $scope.drillDownOptionSelectedIndex = -1;
        $scope.selectedDrillDownOption = {};
        $scope.wsTempParamObj.hierarchyPath = $scope.currentClientCofig.hierarchyPath;
        clearDrillDownHierarchy(1);
        /*end();*/

        $scope.initAggregationData();
        $scope.getAggregationsData($scope.wsTempParamObj);
        //$('#menu-dropdown-open').prop('checked', false);
        console.log();
        //backMenuFunction(mlmenu);
        /* pullMenuEl.classList.remove('open');
         menuDown.spring({
         tension: 100,
         damping: 15
         })
         .to(0, boundry.top).start();*/
        /*$( "#ml-menu .menu__breadcrumbs a:eq(0)").trigger('click');*/
        $scope.metricTypeSelectedIndex = index;
        $scope.navHeaderTwo=$scope.currentClientCofig.drillDownHierarchyLabel;
        if($scope.isPage2Visible){
            $scope.isPage2Visible=false;
            FlickityService.select($scope.flickityId_main, 0);
        }

    }

    $scope.loadHomePage=function(){
        //$scope.metricTypeSelectedIndex = index;
        //$scope.navHeaderTwo=$scope.currentClientCofig.drillDownHierarchyLabel;
        if($scope.isPage2Visible){
            $scope.isPage2Visible=false;
            FlickityService.select($scope.flickityId_main, 0);
        }
    }
    // click event for red, green & yellow
    $scope.onClickCard = function (status) {
        intializeListViewNumbers()
        $scope.aggregationsMetricMasterArr = [];

        $scope.wsTempParamObj.dateRange = $scope.selectedAggregationRecord.interval;
        $scope.wsTempParamObj.status = status;
        /* $scope.processValue = $scope.headerLabel+" "+DASH_ALL_LBL;
         $scope.monthValue=PERIOD_LBL+' '+DASH_ALL_LBL;*/
        $scope.getDrillThroughMetricData($scope.wsTempParamObj);
        //$scope.showDrillMetricRecords();
    };
    // get the Aggregations MetricData
    $scope.getDrillThroughMetricData = function (wsParamObj) {
        // usSpinnerService.spin('spinner-1');
        setTimeout(function(){
            $scope.navigateNextPage();
            if(!$scope.$$phase) {
                $scope.$digest();
            }
        },800);
        var promise = portalservice.getDrillThroughMetricData(wsParamObj, $scope.currentClientCofig.deploymentEnv);
        promise.success(function (response) {
            if (response.errorCode === 0) {
                dashboardDataProcessFactory.processDrillThroughMetricData($scope, response.result);
                // usSpinnerService.stop('spinner-1');

                $scope.isAjaxComplete = true;
                $scope.portalWebSeviceErrorMsg = false;
                $scope.isServiceFailed = false;
            }
            else {
                $scope.portalWebSeviceErrorMsg = true;//response.errorMsg;
                // usSpinnerService.stop('spinner-1');
                $scope.navigateNextPage();
                $scope.showErrorModal(response.errorMessage);
            }
        });
        promise.error(function (err) {
            // usSpinnerService.stop('spinner-1');
            /*$scope.navigateNextPage();*/
            $scope.isServiceFailed = true;
            $scope.showErrorModal(err);
        });
    }

    //format the breadcrumb text
    $scope.formatBreadCrumbText = function (rec) {
        var labelTempArr = [];
        var lblStr = "";
        for (var i = 0; i < 5; i++) {
            if (rec["h" + (i + 1) + "label"] != null && rec["h" + (i + 1) + "label"] != undefined) {
                labelTempArr.push(rec["h" + (i + 1) + "label"]);
            }
        }
        if (parseInt($scope.wsTempParamObj.apiversion) >= 2.0) {
            for (var i = 0; i < labelTempArr.length; i++) {
                if (labelTempArr[i] != undefined) {
                    if (i == labelTempArr.length - 1) {
                        lblStr += labelTempArr[i]
                    } else {
                        lblStr += labelTempArr[i] + " > "
                    }
                }

            }
            return lblStr;
        } else {
            return $scope.currentClientCofig.drillDownHierarchyLabel + " > " + rec.clientGeo + " > " + rec.clientCountry;
        }
    }
    // status icon color
    $scope.getCategoryColor = function (colorCode) {
        switch (colorCode) {
            case "R":
                return {'red': true};
                break;
            case "G":
                return {'green': true};
                break;
            case "Y":
                return {' yellow': true};
                break;
            case 4:
                return {'category_10 fr': true};
                break;
        }
    };


    $('.card-view').on('scroll',function() {
        var top=$('.card-view').scrollTop();
        $(".card-view > li").withinviewport().each(function() {
            var arr= $(this).attr("class").split(" ");
            var elemnt=arr[arr.length-1].slice(4);
            var numOfRecords=parseInt(elemnt);
            if(top<=200){
                $('.view-record').text("1 - 4");
            }
            else{
                $('.view-record').text((numOfRecords-2)+" - "+(numOfRecords + 1));
            }
            if(numOfRecords+1==$scope.aggregationsMetricMasterArr.length && ($scope.aggregationsMetricMasterArr.length%2!=0)){
                $('.view-record').text((numOfRecords-1)+" - "+(numOfRecords + 1));
            }
        });
    });
    $('.list-view').on('scroll',function() {

        $(".list-view > li").withinviewport().each(function() {
            var arr= $(this).attr("class").split(" ");
            var elemnt=arr[arr.length-1].slice(4);
            var numOfRecords=parseInt(elemnt);
            var start=(numOfRecords-($scope.listViewNumberOfRecords-1));
            if(start<=0)
                start=1;
            $('.view-record').text(start+" - "+(numOfRecords + 1));
        });
    });
    var intializeListViewNumbers=function(){
        var ht=$(window).height();
        console.log(ht);
        if(ht>600){
            $scope.listViewNumberOfRecords=7;
        }

    }
    //Page 3 Drill down graph WS integration
    $scope.intializeDrillDownData = function (rec) {
        $scope.selectedMetricRecord = rec;
        $scope.wsTempParamObj.slaFactKey = $scope.selectedMetricRecord.factKey;
        ///$scope.wsTempParamObj.clientName = "pepsico"
        $scope.wsTempParamObj.clientCountry = $scope.selectedMetricRecord.clientCountry;
        $scope.wsTempParamObj.clientGeo = $scope.selectedMetricRecord.clientGeo;
        $scope.wsTempParamObj.isCommentPosted = false;
        $scope.isCommentAdded = false;
        commentsGraphClickedIndex=2;
        $scope.selectedChartPointIndex=0;
        $scope.loadDrillDownGraph($scope.wsTempParamObj);
    }
    // get call for the drill down graph data
    $scope.loadDrillDownGraph = function (wsTempParamObj) {
        $scope.allMonthsMetricsRecords = [];
        // usSpinnerService.spin('spinner-1');
        /*setTimeout(function(){

         },400);*/
        $scope.navigateCommentPage();
        portalservice.getCommentsData(wsTempParamObj, $scope.currentClientCofig.deploymentEnv).success(function (response) {
            if (response.errorCode === 0) {
                $scope.allMonthsMetricsRecords = response.result;
                dashboardDataProcessFactory.processDrillDownGraph($scope, $scope.allMonthsMetricsRecords);
                // usSpinnerService.stop('spinner-1');
                /////$scope.getCommentsData(wsTempParamObj);
                $scope.portalWebSeviceErrorMsg = false;
                $scope.isServiceFailed = false;
            }
            else {
                $scope.portalWebSeviceErrorMsg = true;//response.errorMsg;
                // usSpinnerService.stop('spinner-1');
                $scope.showErrorModal(response.errorMessage);
            }
        }).error(function (err) {
            // usSpinnerService.stop('spinner-1');
            $scope.isServiceFailed = true;
            $scope.showErrorModal(err);
        });
    }
    //For Chart.js 2.0 Multiline labels need to be created by array of labels-[["Jan","2016"]["Feb","2016"]]
    var createMultilineLabels=function(labels){
        labelsArr=[];
        for(var i=0; i<labels.length;i++){
            var arr=[];
            arr= labels[i].split(" ");
            labelsArr[i]=arr;
        }
        return  labelsArr;
    }
    // Function will initialize background color to white by default So that onclick we can change
    var initializeLineChartColor=function(){
        for(var i=0;i<$scope.lineChartCommentData.datasets[0].data.length;i++){
            $scope.lineChartCommentData.datasets[0].pointBackgroundColor[i]="white";
            $scope.lineChartCommentData.datasets[1].pointBackgroundColor[i]="white";
            $scope.lineChartCommentData.datasets[2].pointBackgroundColor[i]="white";
        }
        for(var i=0;i<$scope.lineChartCommentDataLast.datasets[0].data.length;i++){
            $scope.lineChartCommentDataLast.datasets[0].pointBackgroundColor[i]="white";
            $scope.lineChartCommentDataLast.datasets[1].pointBackgroundColor[i]="white";
            $scope.lineChartCommentDataLast.datasets[2].pointBackgroundColor[i]="white";
        }
        lineCommentObj.update();
        //lineCommentObjLast.update();

    }
    $scope.generateDisplayLabelButton=function(arr){
        return arr[0][0]+" "+arr[0][1]+" - "+arr[arr.length-1][0]+" "+arr[arr.length-1][1];
    }
    //load Drill down chart Page 3 ,Select last twelve Months divide into 2 and show in 2 different charts
    $scope.loadDrillDownChart=function(arr){
        console.log(arr);
        var firstHalf=[],seconHalf=[],labelsArr=[];
        $scope.portalLastTwelveMetricGroupRecords=[];
        /*if(arr.length>12){
         $scope.portalLastTwelveMetricGroupRecords= arr.slice(arr.length-12,arr.length);
         }
         else{*/
        $scope.portalLastTwelveMetricGroupRecords=arr;
        /*}
         var flktyCommentData = Flickity.data('.demo___comment_slides');*/
        /*   console.log(flktyCommentData);*/
        /* if($scope.portalLastTwelveMetricGroupRecords.length>6){
         flktyCommentData.bindDrag();
         firstHalf= $scope.portalLastTwelveMetricGroupRecords.slice(0,($scope.portalLastTwelveMetricGroupRecords.length/2));
         seconHalf= $scope.portalLastTwelveMetricGroupRecords.slice(($scope.portalLastTwelveMetricGroupRecords.length/2));
         $scope.lineChartCommentData.datasets[0].data=dashboardDataProcessFactory.createArrayObjectValues(firstHalf,'target');
         $scope.lineChartCommentData.datasets[1].data=dashboardDataProcessFactory.createArrayObjectValues(firstHalf,'min');
         $scope.lineChartCommentData.datasets[2].data=dashboardDataProcessFactory.createArrayObjectValues(firstHalf,'current');
         var labels=dashboardDataProcessFactory.createArrayObjectValues(firstHalf,'displayDate');
         $scope.lineChartCommentData.labels=createMultilineLabels(labels);
         $scope.lineChartCommentDataLast.datasets[0].data=dashboardDataProcessFactory.createArrayObjectValues(seconHalf,'target');
         $scope.lineChartCommentDataLast.datasets[1].data=dashboardDataProcessFactory.createArrayObjectValues(seconHalf,'min');
         $scope.lineChartCommentDataLast.datasets[2].data=dashboardDataProcessFactory.createArrayObjectValues(seconHalf,'current');
         $scope.lineChartCommentDataLast.labels=createMultilineLabels(dashboardDataProcessFactory.createArrayObjectValues(seconHalf,'displayDate'));
         $scope.commentsChartButtonVisible=true;
         $scope.commentBtnLabelLine.firstHalf=$scope.generateDisplayLabelButton($scope.lineChartCommentData.labels);
         $scope.commentBtnLabelLine.secondHalf=$scope.generateDisplayLabelButton($scope.lineChartCommentDataLast.labels);
         onClickChangeBackgroundColor($scope.lineChartCommentDataLast,lineCommentObjLast,($scope.lineChartCommentDataLast.datasets[0].data.length-1));
         }*/
        /*    else{
         flktyCommentData.unbindDrag();
         FlickityService.select($scope.flickityIdComments, 0);*/
        firstHalf= $scope.portalLastTwelveMetricGroupRecords;
        $scope.lineChartCommentData.datasets[0].data=dashboardDataProcessFactory.createArrayObjectValues(firstHalf,'target');
        $scope.lineChartCommentData.datasets[1].data=dashboardDataProcessFactory.createArrayObjectValues(firstHalf,'min');
        $scope.lineChartCommentData.datasets[2].data=dashboardDataProcessFactory.createArrayObjectValues(firstHalf,'current');
        $scope.lineChartCommentData.labels=createMultilineLabels(dashboardDataProcessFactory.createArrayObjectValues(firstHalf,'displayDate'));
        $scope.commentsChartButtonVisible=false;
        onClickChangeBackgroundColor($scope.lineChartCommentData,lineCommentObj,($scope.lineChartCommentData.datasets[0].data.length-1));
        /*}*/




    }
    var onClickChangeBackgroundColor=function(data,obj,index){
        console.log(obj.config.data.datasets[0].pointBackgroundColor);
        /* if(commentsGraphClickedIndex==0){*/
        index=$scope.selectedChartPointIndex;
        obj=lineCommentObj;
        data=$scope.lineChartCommentData;
        /*}
         else if(commentsGraphClickedIndex==1){
         index=$scope.selectedChartPointIndex;
         obj=lineCommentObjLast;
         index=(index-$scope.lineChartCommentDataLast.datasets[0].data.length);
         index=index>=0?index:$scope.selectedChartPointIndex;
         data=$scope.lineChartCommentDataLast;
         }*/
        initializeLineChartColor();
        data.datasets[0].pointBackgroundColor[index]=currentChartTheme.page3.target;
        data.datasets[1].pointBackgroundColor[index]=currentChartTheme.page3.min;
        data.datasets[2].pointBackgroundColor[index]=currentChartTheme.page3.current;
        obj.update();
    }
    $scope.commentChartClick=function(data){
        var activePoints =data.data;
        if(activePoints.length>0) {
            commentsGraphClickedIndex=0;
            var data_index=activePoints[0]._index;
            $scope.selectedGraphRecord=$scope.portalLastTwelveMetricGroupRecords[data_index];
            $scope.selectedChartPointIndex=data_index;
            dashboardDataProcessFactory.processCommentsData($scope,$scope.portalLastTwelveMetricGroupRecords[data_index].comments);
            if(!$scope.$$phase) {
                $scope.$digest();
            }
            onClickChangeBackgroundColor($scope.lineChartCommentData,lineCommentObj,$scope.selectedChartPointIndex);
        }

    }
    /*   $scope.commentLastChartClick=function(data){
     var activePoints =data.data;
     if(activePoints.length>0) {
     commentsGraphClickedIndex=1;
     var data_index=activePoints[0]._index;
     var len=($scope.portalLastTwelveMetricGroupRecords.length/2);
     $scope.selectedChartPointIndex=data_index;
     onClickChangeBackgroundColor($scope.lineChartCommentDataLast,lineCommentObjLast,data_index);
     $scope.selectedChartPointIndex=len+data_index;
     $scope.selectedGraphRecord=$scope.portalLastTwelveMetricGroupRecords[$scope.selectedChartPointIndex];
     dashboardDataProcessFactory.processCommentsData($scope,$scope.portalLastTwelveMetricGroupRecords[$scope.selectedChartPointIndex].comments);
     if(!$scope.$$phase) {
     $scope.$digest();
     }
     }


     }*/

    $scope.onAddComment = function (event) {
        if ($scope.commentArea.comment) {
            $scope.postCommentObj.factkey = $scope.selectedGraphRecord.factKey;
            $scope.postCommentObj.commentAPITokenKey = $scope.currentClientCofig.commentAPITokenKey;
            $scope.postCommentObj.commenttxt = utilityService.handleSingleQuote($scope.commentArea.comment);
            $scope.postCommentObj.userName = $scope.userName;
            $scope.postComment($scope.wsTempParamObj, $scope.postCommentObj);

        } else {

        }

    }
    // post comment API for posting comment
    $scope.postComment = function (wsParamObj, commentObj) {
        // usSpinnerService.spin('spinner-1');
        var promise = portalservice.postComment(wsParamObj, $scope.currentClientCofig.deploymentEnv, commentObj);
        promise.success(function (response) {
            if (response.errorCode === 0) {
                $scope.isCommentAdded = true;
                $scope.wsTempParamObj.isCommentPosted = true;
                $scope.commentArea.comment="";
                $scope.loadDrillDownGraph($scope.wsTempParamObj);
                $scope.$watch(function (scope) {
                        return scope.selectedSLACommentArr
                    },
                    function (newValue, oldValue) {
                        $scope.selectedMetricRecord.commentCount = newValue.length;
                    }
                );
                $timeout(function(){
                    $scope.viewComments();
                },1000);
                // usSpinnerService.stop('spinner-1');
                $scope.isAjaxComplete = true;
                $scope.portalWebSeviceErrorMsg = false;
                $scope.isServiceFailed = false;

            }
            else {
                $scope.portalWebSeviceErrorMsg = true;//response.errorMsg;
                // usSpinnerService.stop('spinner-1');
                $scope.showErrorModal(response.errorMessage);
            }
        });
        promise.error(function (err) {
            // usSpinnerService.stop('spinner-1');
            $scope.isServiceFailed = true;
            $scope.showErrorModal(err);
        });
    }
    $scope.showAddComments=function(){
        $scope.isViewCommentsVisible = false;
        FlickityService.select($scope.flickityIdCommentsWrapper, 0);
    }
    $scope.viewComments=function(){
        $scope.isViewCommentsVisible = true;
        FlickityService.select($scope.flickityIdCommentsWrapper, 1);
    }
    $scope.showErrorModal=function(msg){
        $scope.showDialog=true;
        $scope.errorMessage=msg;
    }
    //New aggregation types count,weighted call
    $scope.changeAggregationsType = function (type) {
        $scope.aggregationsMetricMasterArr = [];
        /*$scope.processValue=$scope.headerLabel+" "+DASH_ALL_LBL;*/
        $scope.weightedAverageOptionIndex = this.$index;
        $scope.selectedAggregationsType=this.rec;
        $scope.wsTempParamObj.aggregationType=$scope.selectedAggregationsType;
        if (!$scope.isPage2Visible) {
            $scope.getAggregationsData($scope.wsTempParamObj);
        }else{
            $scope.getDrillThroughMetricData($scope.wsTempParamObj);
        }
    };
    // toggle theme
    $scope.changeTheme=function(theme){

        if(theme=="theme1" && $scope.selectedTheme!=theme){
            updateChartThemeValues(chartColorPalette.theme1);
            $('link[href="view/style/css/style.css"]').attr({href : "view/style/css/style_light.css"});
            $scope.selectedTheme=theme;
        }
        else if(theme=="theme2" && $scope.selectedTheme!=theme)
        {
            updateChartThemeValues(chartColorPalette.theme2);
            $('link[href="view/style/css/style_light.css"]').attr({href : "view/style/css/style.css"});
            $scope.selectedTheme=theme;
        }

    }

    //New Design changes starts here
    $scope.doughnutChartBottomOption = {
        responsive: true,
        maintainAspectRatio: false,
        tooltips:{
            enabled: false,
        },

        legend: {
            display: false
        },
        title: {
            display: false,
            text: ''
        },
        animation: {
            onProgress:function(obj){
                if($scope.isDonutValueGSet){
                    $('.donutValG').each(function () {
                        $(this).prop('Counter',0).animate({
                            Counter: $(this).text()
                        }, {
                            duration: 1000,
                            easing: 'swing',
                            step: function (now) {
                                $(this).text(Math.ceil(now));
                            }
                        });
                    });
                    $('.donutValY').each(function () {
                        $(this).prop('Counter',0).animate({
                            Counter: $(this).text()
                        }, {
                            duration: 1000,
                            easing: 'swing',
                            step: function (now) {
                                $(this).text(Math.ceil(now));
                            }
                        });
                    });
                    $('.donutValR').each(function () {
                        $(this).prop('Counter',0).animate({
                            Counter: $(this).text()
                        }, {
                            duration: 1000,
                            easing: 'swing',
                            step: function (now) {
                                $(this).text(Math.ceil(now));
                            }
                        });
                    });
                    $scope.isDonutValueGSet=false;
                }


            },
            easing:"easeOutBounce",
            animateScale: true,
            animateRotate: true


        },
        cutoutPercentage: 90
    };
    $scope.doughnutChartBottomDataG = {
        datasets: [{
            data: [20,20],
            borderWidth: 0,
            backgroundColor: ["#008A52","#d9d9d0"],
            hoverBackgroundColor: [],

        }],
        labels: [
            "Below Minimum: ",
            "Over Target: "
        ],

    };
    $scope.doughnutChartBottomDataY = {
        datasets: [{
            data: [20,20],
            borderWidth: 0,
            backgroundColor: ["pink","purple"],
            hoverBackgroundColor: [],
        }],
        labels: [
            "Below Minimum: ",
            "Over Target: "
        ],

    };
    $scope.doughnutChartBottomDataR = {
        datasets: [{
            data: [20,20],
            borderWidth: 0,
            backgroundColor: ["#D9182D","#d9d9d0"],
            hoverBackgroundColor: [],

        }],
        labels: [
            "Below Minimum: ",
            "Over Target: "
        ],

    };
    $scope.getChartObjDoughnutBottomG = function (obj) {
        doughnutChartObjG = obj.chart;
    };
    $scope.getChartObjDoughnutBottomY = function (obj) {
        doughnutChartObjY = obj.chart;
    };
    $scope.getChartObjDoughnutBottomR = function (obj) {
        doughnutChartObjR = obj.chart;
    };
//click will create the layout of breadcrumb
    $scope.onClickBreadCrumb = function (obj, $event) {
        $scope.processValue = $scope.headerLabel+" "+DASH_ALL_LBL;
        //$scope.monthValue= PERIOD_LBL+' '+DASH_ALL_LBL;
        ///$scope.aggregationsProcessArr = [];
        $scope.aggregationsMetricMasterArr = [];
        $scope.portalProcessSelectedIndex=0;
        $scope.portalMonthSelectedIndex=0;
        $scope.isCardViewVisible = false;
        var index = parseInt(obj.id) + 1;
        $scope.drillDownHierarchyArr.splice(index, $scope.drillDownHierarchyArr.length - 1);
        //console.log(obj.level);
        if ($scope.wsTempParamObj.apiversion == "2.0" || $scope.wsTempParamObj.apiversion == "2.1" || $scope.wsTempParamObj.apiversion == "2.2" || $scope.wsTempParamObj.apiversion == "3.0") {
            if ($scope.getDrillDownPath($scope.drillDownHierarchyArr).charAt($scope.getDrillDownPath($scope.drillDownHierarchyArr).length - 1) == '|' && obj.level != "H0") {
                //console.log($scope.getDrillDownPath($scope.drillDownHierarchyArr).substr(0, $scope.getDrillDownPath($scope.drillDownHierarchyArr).length - 1))
                $scope.wsTempParamObj.hierarchyPath = $scope.getDrillDownPath($scope.drillDownHierarchyArr).substr(0, $scope.getDrillDownPath($scope.drillDownHierarchyArr).length - 1)
                console.log($scope.wsTempParamObj.hierarchyPath);
            } else {

                $scope.wsTempParamObj.hierarchyPath = obj.level + ":" + obj.label;
                console.log("........"+$scope.wsTempParamObj.hierarchyPath);
            }
        } else {
            $scope.wsTempParamObj.hierarchyPath = obj.level + ":" + obj.label;
            console.log(">>>>>>"+$scope.wsTempParamObj.hierarchyPath);
        }
        console.log(obj.level);
        $scope.level=obj.level;
        console.log($scope.level);
        var tempIndex=obj.level.substring(1, 2);
        if($scope.drillDownLabelArr.length>0){
            if($scope.drillDownLabelArr[parseInt(tempIndex)+1]!=undefined && $scope.drillDownLabelArr[parseInt(tempIndex)+1]!="" || $scope.drillDownLabelArr[parseInt(tempIndex)+1]!=null){
                $scope.optionLabel = $scope.drillDownLabelArr[parseInt(tempIndex)+1];
            }else{
                $scope.optionLabel=DASH_DRILL_DOWN_LBL;
            }
        }

        $scope.portalMonthSelectedIndex = 0;
        $scope.drillDownOptionSelectedIndex = -1;
        $scope.selectedDrillDownOption = {};
        $scope.initAggregationData();

        $scope.getAggregationsData($scope.wsTempParamObj);
        $scope.getFullHierarchy($scope.wsTempParamObj);
        $event.preventDefault();
    }



    $scope.doughnutModal=false;

    $scope.openDoughnutModal=function(modalId){
        $scope.doughnutModal=true;
    }

    //show the tree-map
    $scope.getFullHierarchy=function(wsTempParamObj){
        portalservice.getFullHierarchy(wsTempParamObj, $scope.currentClientCofig.deploymentEnv).success(function (response) {
            if (response.errorCode === 0) {
                dashboardDataProcessFactory.processTreeMapData($scope, response.result);
                $scope.portalWebSeviceErrorMsg = false;
                $scope.isServiceFailed = false;
            }
            else {
                $scope.portalWebSeviceErrorMsg = true;//response.errorMsg;
                // usSpinnerService.stop('spinner-1');
                $scope.showErrorModal(response.errorMessage);
            }
        }).error(function (err) {
            // usSpinnerService.stop('spinner-1');
            $scope.isServiceFailed = true;
            $scope.showErrorModal(err);
        });
    }
    //Code to handle width for side menu
    // $( ".container-main-dashboard .side-panel" ).hover(function() {
    //     $('.container-main-dashboard').css('min-width','1300px');
    // });
    // $( ".main-panel" ).on('click',function() {
    //     setTimeout(function(){
    //         $('.container-main-dashboard').css('min-width','1024px');
    //     },800);

    // });

    $scope.formatMetricData=function(data,type,rec,subType){

        ////console.log(data+" "+maxNumber);
        switch(type.toLowerCase()){
            case "percentage":
                return data != null ?'height: '+data:"height:0%";
            case "dollar":
                var maxValue=utilityService.findMaxNumber(rec.min,rec.target,rec.actual,type);
                var calValPercentageVal=utilityService.percentageOfBarGraph(rec,maxValue,subType)
                return data != null ?'height: '+calValPercentageVal+'%':"height:0%";
            case "count":

                var maxValue=utilityService.findMaxNumber(rec.min,rec.target,rec.actual,type);
                var calValPercentageVal=utilityService.percentageOfBarGraph(rec,maxValue,subType)
                return data != null ?'height: '+calValPercentageVal+'%':"height:0%";


            case "days":
                var maxValue=utilityService.findMaxNumber(rec.min,rec.target,rec.actual,type);
                var calValPercentageVal=utilityService.percentageOfBarGraph(rec,maxValue,subType)
                return data != null ?'height: '+calValPercentageVal+'%':"height:0%";

        }
    }

    $scope.showTable=false;

    $scope.openModalWindow=function(modalId){
        $scope.getHierarchyCommentListData($scope.wsTempParamObj);
        $scope.showTable=true;
    }



    $scope.convertToMonthYearFormat = function (rec) {
        var year = String(rec.interval).substring(0, String(rec.interval).length - 2);
        var month = String(rec.interval).substring(String(rec.interval).length - 2, String(rec.interval).length);
        var timestamp = utilityService.convertToTimeStamp(parseInt(year), parseInt(month), 15, 16, 0, 0);
        return utilityService.convertToYearMonthFormat(timestamp);
    }



});


